﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;

namespace Innocellence.FaultSearch.Services
{
    public interface IDetectSubInputService : IDependency, IBaseService<DetectSubInputEntity>
    {

        List<DetectSubInputEntity> GetFEInfos();
        List<T> GetList<T>(Expression<Func<DetectSubInputEntity, bool>> predicate) where T : IViewModel, new();
        string GetDetectNum(string id);
    }
}
