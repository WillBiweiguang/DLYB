﻿using Infrastructure.Core.Data;
using Infrastructure.Utility.Data;
using Innocellence.CA.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Entity;
using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using System.Threading.Tasks;
using Innocellence.CA.Services;
using Innocellence.CA.Contracts;
using Innocellence.CA.ModelsView;
using EntityFramework.Extensions;
namespace Innocellence.FaultSearch.Service
{
    public class AnsysTypeService : BaseService<AnsysTypeEntity>, IAnsysTypeService
    {
        private static List<AnsysTypeEntity> FEInfos = null;
        private readonly IQuestionImagesService _objImageService = new QuestionImagesService();
        public List<AnsysTypeEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }


        public AnsysTypeService()
            : base("CAAdmin")
        {
        }


        public IList<AnsysTypeEntity> QueryList(Expression<Func<AnsysTypeEntity, bool>> func)
        {
            return Repository.Entities.Where(func).ToList();
        }
        public List<AnsysTypeView> GetBasicQuerys()
        {
            return Repository.Entities.Select(x => new AnsysTypeView()
            {
                Category = x.Category
            }).Distinct().ToList();
        }

        public List<T> GetListByDate<T>(Expression<Func<AnsysTypeEntity, bool>> predicate) where T : Infrastructure.Core.IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public List<T> GetList<T>(Expression<Func<AnsysTypeEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public override int InsertView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as AnsysTypeView;
            var entity = new AnsysTypeEntity()
            {
                ProjectName = objView.ProjectName,
                Category = objView.Category,
            };
            if (objView == null)
            {
                return -1;
            }
            iRet = Repository.Insert(entity);

            objView.Id = entity.Id;

            var ser = new BaseService<QuestionImages>("CAAdmin");
            if (!string.IsNullOrEmpty(objView.ImageIdList))
            {
                foreach (var imageid in objView.ImageIdList.Split(','))
                {
                    if (!string.IsNullOrEmpty(imageid))
                    {
                        var qt = new QuestionImages { Id = int.Parse(imageid), QuestionID = objView.Id };
                        ser.Repository.Update(qt, new List<string>() { "QuestionID" });
                    }
                }
            }
            return iRet;
        }

        public override int UpdateView<T>(T objModalSrc)
        {
            int iRet;
            var objModal = objModalSrc as AnsysTypeView;

            if (objModal == null)
            {
                return -1;
            }
            int Id = objModal.Id;

            iRet = Repository.Entities.Where(x => x.Id == Id)
           .Update(x => new AnsysTypeEntity { ProjectName = objModal.ProjectName, Category = objModal.Category });

            var ser = new BaseService<QuestionImages>("CAAdmin");
            if (!string.IsNullOrEmpty(objModal.ImageIdList))
            {
                foreach (var imageid in objModal.ImageIdList.Split(','))
                {
                    if (!string.IsNullOrEmpty(imageid))
                    {
                        var qt = new QuestionImages { Id = int.Parse(imageid), QuestionID = objModal.Id };
                        ser.Repository.Update(qt, new List<string>() { "QuestionID" });
                    }
                }
            }
            return iRet;
        }
        public AnsysTypeView GetImagesDetail(string id, string category)
        {
            var questionView = Repository.Entities.Where(x => x.ProjectName == id & x.Category == category).ToList().
                Select(n => (AnsysTypeView)(new AnsysTypeView().ConvertAPIModel(n))).FirstOrDefault();
            if (questionView != null)
            {
                questionView.QuestionImages = _objImageService.GetListByQuestionID<QuestionImagesView>(questionView.Id);
            }
            else
            {
                questionView = new AnsysTypeView();
            }
            return questionView;
        }
    }
}