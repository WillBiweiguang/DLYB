﻿using Infrastructure.Core.Data;
using Infrastructure.Utility.Data;
using Innocellence.CA.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;

namespace Innocellence.FaultSearch.Service
{
    public class FaultSearchService : BaseService<FaultSearchEntity>, IFaultSearchService
    {
        private static List<FaultSearchEntity> FEInfos = null;
        public List<FaultSearchEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }
        

        public FaultSearchService()
            : base("CAAdmin")
        {
        }

        public List<FaultSearchView> GetFailureQuerys()
        {
            return Repository.Entities.Where(y=>y.IsDeleted!=true).Select(x => new FaultSearchView()
            {
                FailureClass = x.FailureClass,
                FailureMode = x.FailureMode
            }).Distinct().ToList();
        }
        public IList<FaultSearchEntity> QueryList(Expression<Func<FaultSearchEntity, bool>> func)
        {
            return Repository.Entities.Where(func).ToList();
        }


        public List<T> GetListByDate<T>(Expression<Func<FaultSearchEntity, bool>> predicate) where T : Infrastructure.Core.IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public List<T> GetList<T>(Expression<Func<FaultSearchEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
    }
}