﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;
using Infrastructure.Utility.Data;

namespace Innocellence.FaultSearch.Services
{
    public interface IGasInputService : IDependency, IBaseService<GasInputEntity>
    {
        int GetId(string GasNum);
       
        IList<GasInputEntity> QueryList(Expression<Func<GasInputEntity, bool>> func);
        List<GasInputEntity> GetFEInfos();
        List<T> GetList<T>(Expression<Func<GasInputEntity, bool>> predicate) where T : IViewModel, new();
        List<GasInputView> GetList1(Expression<Func<GasInputEntity, bool>> predicate, PageCondition page);
        List<GasInputView> GetBasicQuerys();
        GasInputView GetInfo(int id);
        GasInputView GetRegularDetail(string id);
        GasInputView GetPostponeDetailFromGas(string id, String projectName);
        GasInputView GetInfoViaName(string name);
        GasInputView GetAnsysDetail(string id);
        GasInputView GetAllReadInfo(string id, string projectName);
        int GetProjectId(string GasNum, string projectName);
        GasInputView GetInfoviaProject(string GasNum, string projectName);
        GasInputView GetPostponeDetail(string id);
        GasInputView GetRegularFromGas(string id, String projectName);
    }
}
