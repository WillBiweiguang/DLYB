﻿using Infrastructure.Core.Data;
using Infrastructure.Utility.Data;
using Innocellence.CA.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Entity;
using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using System.Threading.Tasks;

namespace Innocellence.FaultSearch.Service
{
    public class DetectSubInputService : BaseService<DetectSubInputEntity>, IDetectSubInputService
    {
        private static List<DetectSubInputEntity> FEInfos = null;
        public List<DetectSubInputEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }


        public DetectSubInputService()
            : base("CAAdmin")
        {
        }
        public string GetDetectNum(string id)
        {
            return Repository.Entities.Where(x => x.ProjectName == id).ToList().Select(x => x.DetectNum).FirstOrDefault();
        }
        public List<T> GetList<T>(Expression<Func<DetectSubInputEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public override int InsertView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as DetectSubInputView;
            var entity = new DetectSubInputEntity()
            {

                DetectNum = objView.DetectNum,
                ProjectName=objView.ProjectName
            };
            if (objView == null)
            {
                return -1;
            }
            iRet = Repository.Insert(entity);

            return iRet;
        }
        public virtual int UpdateView<T>(T obj, List<string> lst) where T : IViewModel
        {
            var objView = obj as DetectSubInputView;
            var entity = new DetectSubInputEntity()
            {
                DetectNum = objView.DetectNum,
                ProjectName = objView.ProjectName
            };
            if (objView == null)
            {
                return -1;
            }

            return Repository.Update(entity, lst);
        }
       
    }
}