﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;

namespace Innocellence.FaultSearch.Services
{
    public interface IPostponeInspectService : IDependency, IBaseService<PostponeInspectEntity>
    {
        IList<PostponeInspectEntity> QueryList(Expression<Func<PostponeInspectEntity, bool>> func);
        List<PostponeInspectEntity> GetFEInfos();
        List<T> GetList<T>(Expression<Func<PostponeInspectEntity, bool>> predicate) where T : IViewModel, new();
        PostponeInspectView GetPostponeDetail(string id);
        List<PostponeInspectView> GetPostponeQuerys();
        List<PostponeInspectView> GetPostPoneList(string Id);
        PostponeInspectView GetPostponeSingle(string id, string inspectNum);
    }
}
