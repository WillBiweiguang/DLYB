﻿using Infrastructure.Core.Data;
using Infrastructure.Utility.Data;
using Innocellence.CA.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;

namespace Innocellence.FaultSearch.Service
{
    public class FaultModeService : BaseService<FaultModeEntity>, IFaultModeService
    {
        private static List<FaultModeEntity> FEInfos = null;
        public List<FaultModeEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }


        public FaultModeService()
            : base("CAAdmin")
        {
        }

        public List<FaultModeView> GetFailureQuerys()
        {
            return Repository.Entities.Where(y=>y.IsDeleted!=true).Select(x => new FaultModeView()
            {
                FailureResult = x.FailureResult,
                ReasonOne = x.ReasonOne,
                ReasonTwo=x.ReasonTwo,
                ReasonThree=x.ReasonThree,
                ReasonFour=x.ReasonFour,
                ReasonFive=x.ReasonFive
            }).Distinct().ToList();
        }
        public IList<FaultModeEntity> QueryList(Expression<Func<FaultModeEntity, bool>> func)
        {
            return Repository.Entities.Where(func).ToList();
        }


        public List<T> GetListByDate<T>(Expression<Func<FaultModeEntity, bool>> predicate) where T : Infrastructure.Core.IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public List<T> GetList<T>(Expression<Func<FaultModeEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public override int InsertView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as FaultModeView;
            var entity = new FaultModeEntity()
            {

                ProjectName = objView.ProjectName,
                ReasonOne = objView.ReasonOne,
                ReasonTwo = objView.ReasonTwo,
                FailureResult = objView.FailureResult,
                ReasonThree = objView.ReasonThree,
                ReasonFour = objView.ReasonFour,
                ReasonFive = objView.ReasonFive
            };
            if (objView == null)
            {
                return -1;
            }
            iRet = Repository.Insert(entity);

            return iRet;
        }

        public override int UpdateView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as FaultModeView;

            if (objView == null)
            {
                return -1;
            }
            var entity = new FaultModeEntity()
            {
                Id = objView.Id,
                ProjectName = objView.ProjectName,
                ReasonOne = objView.ReasonOne,
                ReasonTwo = objView.ReasonTwo,
                FailureResult = objView.FailureResult,
                ReasonThree = objView.ReasonThree,
                ReasonFour = objView.ReasonFour,
                ReasonFive = objView.ReasonFive
            };
            iRet = Repository.Update(entity);
            return iRet;
        }
    }
}