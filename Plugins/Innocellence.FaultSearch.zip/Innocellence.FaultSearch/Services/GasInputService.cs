﻿using Infrastructure.Core.Data;
using Infrastructure.Utility.Data;
using Innocellence.CA.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Entity;
using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using System.Threading.Tasks;

namespace Innocellence.FaultSearch.Service
{
    public class GasInputService : BaseService<GasInputEntity>, IGasInputService
    {
        private static List<GasInputEntity> FEInfos = null;
        private readonly IDetectSubInputService _objDetectSubInput = new DetectSubInputService();
        private readonly IPostponeInspectService _objPostponeService = new PostponeInspectService();
        private readonly IRegularInspectService _objRegularService = new RegularInspectService();
        public List<GasInputEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }


        public GasInputService()
            : base("CAAdmin")
        {
        }
        public int GetId(string GasNum)
        {
            return Repository.Entities.Where(x => x.BottleNum == GasNum && x.IsDeleted == false).Select(x => x.Id).FirstOrDefault();
        }
        public int GetProjectId(string GasNum, string projectName)
        {
            return Repository.Entities.Where(x => x.BottleNum == GasNum && x.ProjectName == projectName && x.IsDeleted == false).Select(x => x.Id).FirstOrDefault();
        }
        public GasInputView GetInfoviaProject(string GasNum, string projectName)
        {
            return Repository.Entities.Where(x => x.BottleNum == GasNum && x.ProjectName == projectName && x.IsDeleted == false)
                .Select(x => new GasInputView()
                {
                    Id = x.Id,
                    ProjectName = x.ProjectName,
                    UseCompany = x.UseCompany,
                    MadeCompany = x.MadeCompany,
                    BottleNum = x.BottleNum,
                    Volume = x.Volume,
                    MadeTime = x.MadeTime,
                    DesignWall = x.DesignWall,
                }).FirstOrDefault();
        }
        public GasInputView GetInfo(int id)
        {
            return Repository.Entities.Where(x => x.Id == id && x.IsDeleted == false)
                .Select(x => new GasInputView()
                {
                    ProjectName = x.ProjectName,
                    UseCompany = x.UseCompany,
                    MadeCompany = x.MadeCompany,
                    BottleNum = x.BottleNum,
                    Volume = x.Volume,
                    MadeTime = x.MadeTime,
                    DesignWall = x.DesignWall,
                }).FirstOrDefault();
        }
        public GasInputView GetInfoViaName(string name)
        {
            return Repository.Entities.Where(x => x.BottleNum == name && x.IsDeleted == false).
                Select(x => new GasInputView()
                {
                    Id = x.Id,
                    ProjectName = x.ProjectName,
                    UseCompany = x.UseCompany,
                    MadeCompany = x.MadeCompany,
                    BottleNum = x.BottleNum,
                    Volume = x.Volume,
                    MadeTime = x.MadeTime,
                    DesignWall = x.DesignWall,
                }).FirstOrDefault();
        }
        public IList<GasInputEntity> QueryList(Expression<Func<GasInputEntity, bool>> func)
        {
            return Repository.Entities.Where(func).ToList();
        }
        public List<GasInputView> GetBasicQuerys()
        {
            return Repository.Entities.Select(x => new GasInputView()
            {
                BottleNum = x.BottleNum,
                Id = x.Id,
                ProjectName = x.ProjectName,
            }).Distinct().ToList();
        }

        public List<T> GetListByDate<T>(Expression<Func<GasInputEntity, bool>> predicate) where T : Infrastructure.Core.IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public List<T> GetList<T>(Expression<Func<GasInputEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public override int InsertView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as GasInputView;
            var entity = new GasInputEntity()
            {
                ProjectName = objView.ProjectName,
                UseCompany = objView.UseCompany,
                MadeCompany = objView.MadeCompany,
                BottleNum = objView.BottleNum,
                Volume = objView.Volume,
                MadeTime = objView.MadeTime,
                DesignWall = objView.DesignWall,
            };
            if (objView == null)
            {
                return -1;
            }
            iRet = Repository.Insert(entity);

            return iRet;
        }
        public virtual int UpdateView<T>(T obj, List<string> lst) where T : IViewModel
        {
            var objView = obj as GasInputView;
            var entity = new GasInputEntity()
            {

                ProjectName = objView.ProjectName,
                UseCompany = objView.UseCompany,
                MadeCompany = objView.MadeCompany,
                BottleNum = objView.BottleNum,
                Volume = objView.Volume,
                MadeTime = objView.MadeTime,
                DesignWall = objView.DesignWall,
            };
            if (objView == null)
            {
                return -1;
            }

            return Repository.Update(entity, lst);
        }
        public override int UpdateView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as GasInputView;
            var entity = new GasInputEntity()
            {
                Id = objView.Id,
                ProjectName = objView.ProjectName,
                UseCompany = objView.UseCompany,
                MadeCompany = objView.MadeCompany,
                BottleNum = objView.BottleNum,
                Volume = objView.Volume,
                MadeTime = objView.MadeTime,
                DesignWall = objView.DesignWall,
            };
            if (objView == null)
            {
                return -1;
            }

            iRet = Repository.Update(entity);

            return iRet;
        }
        public List<GasInputView> GetList1(Expression<Func<GasInputEntity, bool>> predicate, PageCondition page)
        {
            var total = 0;
            List<GasInputView> gasinputViewlist;
            List<GasInputView> newgasinputViewlist = new List<GasInputView>();
            GasInputView gs = new GasInputView();

            //gasinputViewlist = GetList<GasInputView>(predicate, page.PageIndex, page.PageSize, ref total, page.SortConditions);
            //page.RowCount = total;
            gasinputViewlist = GetBasicQuerys();
            // gasinputViewlist = Repository.Entities.Where(x => x.IsDeleted != true).ToList().Select(n => (GasInputView)(new GasInputView().ConvertAPIModel(n))).ToList();
            gasinputViewlist.ForEach(d =>
            {
               
                var cate = _objDetectSubInput.GetDetectNum(d.Id.ToString());
                if (cate == "2")
                {
                    gs.PIList = _objPostponeService.GetPostPoneList(d.Id.ToString());
                    gs.PIList.ForEach(m =>
                    {
                        GasInputView a = new GasInputView();
                        a.Id = d.Id;
                        a.ProjectName = d.ProjectName;
                        a.BottleNum = d.BottleNum;
                        a.CheckStandard = "《液化石油气钢瓶延期使用安全评估》";
                        PostponeInspectView PI = new PostponeInspectView();
                        PI = m;
                        a.CheckNum = PI.InspectNum;
                        a.MeetStandard = PI.SyncTest;
                        newgasinputViewlist.Add(a);
                    });
                }

                else if (cate == "1")
                {
                   
                    gs.RIList = _objRegularService.GetRegularList(d.Id.ToString());
                    gs.RIList.ForEach(m =>
                    {
                        GasInputView a = new GasInputView();
                        a.Id = d.Id;
                        a.ProjectName = d.ProjectName;
                        a.BottleNum = d.BottleNum;
                        a.CheckStandard = "GB 8334-2011《液化石油气钢瓶定期检验与评定》";
                        RegularInspectView RI = new RegularInspectView();
                        RI = m;
                        a.CheckNum = RI.InspectNum;
                        a.MeetStandard = RI.SyncTest;
                        newgasinputViewlist.Add(a);
                    });

                }
            });
            return newgasinputViewlist;
        }
        public GasInputView GetAllReadInfo(string name, string projectName)
        {
            GasInputView gasinputView;

            int Id = Repository.Entities.Where(x => x.BottleNum == name && x.ProjectName == projectName && x.IsDeleted == false).
                 Select(x => x.Id).FirstOrDefault();
            string id = Id.ToString();
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new GasInputView();
                gasinputView.DSI = new DetectSubInputView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.Id == Id && x.IsDeleted != true).ToList()
                    .Select(x => new GasInputView()
                    {
                        Id = x.Id,
                        ProjectName = x.ProjectName,
                        UseCompany = x.UseCompany,
                        MadeCompany = x.MadeCompany,
                        BottleNum = x.BottleNum,
                        Volume = x.Volume,
                        MadeTime = x.MadeTime,
                        DesignWall = x.DesignWall,
                    }).FirstOrDefault();
                if (gasinputView != null)
                {
                    gasinputView.DSI = new DetectSubInputView();
                    gasinputView.DI = new DetectInputView();
                    gasinputView.DSI.DetectNum = _objDetectSubInput.GetDetectNum(id);
                    //延期检验
                    if (gasinputView.DSI.DetectNum == "2")
                    {
                        gasinputView.DI.ContentText = "《液化石油气钢瓶延期使用安全评估》";
                        gasinputView.PIList = _objPostponeService.GetPostPoneList(id);
                    }
                    else
                    {
                        gasinputView.DI.ContentText = "GB 8334-2011《液化石油气钢瓶定期检验与评定》";
                        gasinputView.RIList = _objRegularService.GetRegularList(id);
                    }
                }
                else
                {
                    gasinputView = new GasInputView();
                    gasinputView.DSI = new DetectSubInputView();
                }
            }
            return gasinputView;
        }
        //应急，先做成单的
        public GasInputView GetPostponeDetail(string id)
        {
            GasInputView gasinputView;
            int Id = int.Parse(id);
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new GasInputView();
                gasinputView.PI = new PostponeInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.Id == Id && x.IsDeleted != true).ToList()
                    .Select(x => new GasInputView()
                    {
                        ProjectName = x.ProjectName,
                        UseCompany = x.UseCompany,
                        MadeCompany = x.MadeCompany,
                        BottleNum = x.BottleNum,
                        Volume = x.Volume,
                        MadeTime = x.MadeTime,
                        DesignWall = x.DesignWall,
                    }).FirstOrDefault();
                if (gasinputView != null)
                {
                    gasinputView.PI = _objPostponeService.GetPostponeDetail(id);
                }
                else
                {
                    gasinputView = new GasInputView();
                    gasinputView.PI = new PostponeInspectView();
                }
            }
            return gasinputView;
        }
        public GasInputView GetPostponeDetailFromGas(string id, String projectName)
        {
            GasInputView gasinputView;
            int Id = int.Parse(id);
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new GasInputView();
                gasinputView.PI = new PostponeInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.Id == Id && x.IsDeleted != true).ToList()
                    .Select(x => new GasInputView()
                    {
                        ProjectName = x.ProjectName,
                        UseCompany = x.UseCompany,
                        MadeCompany = x.MadeCompany,
                        BottleNum = x.BottleNum,
                        Volume = x.Volume,
                        MadeTime = x.MadeTime,
                        DesignWall = x.DesignWall,
                    }).FirstOrDefault();
                if (gasinputView != null)
                {
                    gasinputView.PI = _objPostponeService.GetPostponeSingle(id, projectName);
                }
                else
                {
                    gasinputView = new GasInputView();
                    gasinputView.PI = new PostponeInspectView();
                }
            }
            return gasinputView;
        }

        public GasInputView GetRegularDetail(string id)
        {
            GasInputView gasinputView;
            var Id = int.Parse(id);
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new GasInputView();
                gasinputView.RI = new RegularInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.Id == Id).ToList()
                    .Select(x => new GasInputView()
                    {
                        ProjectName = x.ProjectName,
                        UseCompany = x.UseCompany,
                        MadeCompany = x.MadeCompany,
                        BottleNum = x.BottleNum,
                        Volume = x.Volume,
                        MadeTime = x.MadeTime,
                        DesignWall = x.DesignWall,
                    }).FirstOrDefault();
                if (gasinputView != null)
                {
                    gasinputView.RI = _objRegularService.GetRegularInspectDetail(id);
                }
                else
                {
                    gasinputView = new GasInputView();
                    gasinputView.RI = new RegularInspectView();
                }
            }
            return gasinputView;
        }

        public GasInputView GetRegularFromGas(string id, String projectName)
        {
            GasInputView gasinputView;
            var Id = int.Parse(id);
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new GasInputView();
                gasinputView.RI = new RegularInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.Id == Id).ToList()
                    .Select(x => new GasInputView()
                    {
                        ProjectName = x.ProjectName,
                        UseCompany = x.UseCompany,
                        MadeCompany = x.MadeCompany,
                        BottleNum = x.BottleNum,
                        Volume = x.Volume,
                        MadeTime = x.MadeTime,
                        DesignWall = x.DesignWall,
                    }).FirstOrDefault();
                if (gasinputView != null)
                {
                    gasinputView.RI = _objRegularService.GetRegularInspectSingle(id, projectName);
                }
                else
                {
                    gasinputView = new GasInputView();
                    gasinputView.RI = new RegularInspectView();
                }
            }
            return gasinputView;
        }
        public GasInputView GetAnsysDetail(string id)
        {
            GasInputView gasinputView;
            var Id = int.Parse(id);
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new GasInputView();
                gasinputView.AT = new AnsysTypeView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.Id == Id).ToList()
                    .Select(x => new GasInputView()
                    {
                        ProjectName = x.ProjectName,
                        UseCompany = x.UseCompany,
                        MadeCompany = x.MadeCompany,
                        BottleNum = x.BottleNum,
                        Volume = x.Volume,
                        MadeTime = x.MadeTime,
                        DesignWall = x.DesignWall,
                    }).FirstOrDefault();

            }
            return gasinputView;
        }
    }
}