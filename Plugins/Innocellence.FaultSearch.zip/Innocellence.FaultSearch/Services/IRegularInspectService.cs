﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;


namespace Innocellence.FaultSearch.Services
{
    public interface IRegularInspectService : IDependency, IBaseService<RegularInspectEntity>
    {
        IList<RegularInspectEntity> QueryList(Expression<Func<RegularInspectEntity, bool>> func);
        List<RegularInspectEntity> GetFEInfos();
        List<T> GetList<T>(Expression<Func<RegularInspectEntity, bool>> predicate) where T : IViewModel, new();
        RegularInspectView GetRegularInspectDetail(string id);
        List<RegularInspectView> GetRegularList(string Id);
        RegularInspectView GetRegularInspectSingle(string id, string inspectNum);
    }
}
