﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;

namespace Innocellence.FaultSearch.Services
{
    public interface IDetectInputService : IDependency, IBaseService<DetectInputEntity>
    {

        List<DetectInputEntity> GetFEInfos();
        List<T> GetList<T>(Expression<Func<DetectInputEntity, bool>> predicate) where T : IViewModel, new();
     
    }
}
