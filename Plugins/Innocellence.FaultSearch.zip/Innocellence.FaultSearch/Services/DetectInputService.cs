﻿using Infrastructure.Core.Data;
using Infrastructure.Utility.Data;
using Innocellence.CA.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Entity;
using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using System.Threading.Tasks;

namespace Innocellence.FaultSearch.Service
{
    public class DetectInputService : BaseService<DetectInputEntity>, IDetectInputService
    {
        private static List<DetectInputEntity> FEInfos = null;
        public List<DetectInputEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }


        public DetectInputService()
            : base("CAAdmin")
        {
        }

        public List<T> GetList<T>(Expression<Func<DetectInputEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public override int InsertView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as DetectInputView;
            var entity = new DetectInputEntity()
            {
                
                ContentText = objView.ContentText
            };
            if (objView == null)
            {
                return -1;
            }
            iRet = Repository.Insert(entity);

            return iRet;
        }
        public virtual int UpdateView<T>(T obj, List<string> lst) where T : IViewModel
        {
            var objView = obj as DetectInputView;
            var entity = new DetectInputEntity()
            {
                ContentText = objView.ContentText
            };
            if (objView == null)
            {
                return -1;
            }

            return Repository.Update(entity, lst);
        }
       
    }
}