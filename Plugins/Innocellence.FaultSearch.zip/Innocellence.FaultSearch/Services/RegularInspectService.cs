﻿using Infrastructure.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;

namespace Innocellence.FaultSearch.Service
{
    public class RegularInspectService : BaseService<RegularInspectEntity>, IRegularInspectService
    {
        private static List<RegularInspectEntity> FEInfos = null;
        public List<RegularInspectEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }


        public RegularInspectService()
            : base("CAAdmin")
        {
        }

        public List<RegularInspectView> GetFailureQuerys()
        {
            return Repository.Entities.Select(x => new RegularInspectView()
            {
                InspectNum = x.InspectNum,
                InspectDes = x.InspectDes
            }).Distinct().ToList();
        }
        public IList<RegularInspectEntity> QueryList(Expression<Func<RegularInspectEntity, bool>> func)
        {
            return Repository.Entities.Where(func).ToList();
        }


        public List<T> GetListByDate<T>(Expression<Func<RegularInspectEntity, bool>> predicate) where T : Infrastructure.Core.IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public List<T> GetList<T>(Expression<Func<RegularInspectEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public override int InsertView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as RegularInspectView;
            var entity = new RegularInspectEntity()
            {
                ProjectName = objView.ProjectName,
                InspectNum = objView.InspectNum,
                InspectDes = objView.InspectDes,
                TopOne = objView.TopOne,
                TopTwo = objView.TopTwo,
                BarrelOne = objView.BarrelOne,
                BarrelTwo = objView.BarrelTwo,
                BarrelThree = objView.BarrelThree,
                BottomOne = objView.BottomOne,
                BottomTwo = objView.BottomTwo,

                BottomThree = objView.BottomThree,
                VolumnTest = objView.VolumnTest,
                VacuumTest=objView.VacuumTest,
                WaterTest = objView.WaterTest,
                BottleTest = objView.BottleTest,
                GasTest = objView.GasTest,
                SyncTest = objView.SyncTest,
                EvalDate = objView.EvalDate,
            };
            if (objView == null)
            {
                return -1;
            }
            iRet = Repository.Insert(entity);

            return iRet;
        }

        public override int UpdateView<T>(T objModalSrc)
        {
            int iRet;
            var objModal = objModalSrc as RegularInspectView;

            if (objModal == null)
            {
                return -1;
            }
            int Id = objModal.Id;

            iRet = base.UpdateView(objModal);

            return iRet;
        }
        public List<RegularInspectView> GetRegularList(string Id)
        {
            
            return Repository.Entities.Where(x => x.ProjectName == Id && x.IsDeleted == false).Select(entity => new RegularInspectView
            {
                Id = entity.Id,
                ProjectName = entity.ProjectName,
                InspectNum = entity.InspectNum,
                InspectDes = entity.InspectDes,
                TopOne = entity.TopOne,
                TopTwo = entity.TopTwo,

                BarrelOne = entity.BarrelOne,
                BarrelTwo = entity.BarrelTwo,
                BarrelThree = entity.BarrelThree,

                BottomOne = entity.BottomOne,
                BottomTwo = entity.BottomTwo,
                BottomThree = entity.BottomThree,

                VolumnTest = entity.VolumnTest,
                WaterTest = entity.WaterTest,
                BottleTest = entity.BottleTest,
                GasTest = entity.GasTest,
                VacuumTest = entity.VacuumTest,
                SyncTest = entity.SyncTest,
                EvalDate = entity.EvalDate,

            }).Distinct().ToList();
        }
        public RegularInspectView GetRegularInspectDetail(string id)
        {
            RegularInspectView gasinputView;
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new RegularInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.ProjectName == id).ToList().
                     Select(entity => new RegularInspectView
                     {
                         Id = entity.Id,
                         ProjectName = entity.ProjectName,
                         InspectNum = entity.InspectNum,
                         InspectDes = entity.InspectDes,
                         TopOne = entity.TopOne,
                         TopTwo = entity.TopTwo,

                         BarrelOne = entity.BarrelOne,
                         BarrelTwo = entity.BarrelTwo,
                         BarrelThree = entity.BarrelThree,

                         BottomOne = entity.BottomOne,
                         BottomTwo = entity.BottomTwo,
                         BottomThree = entity.BottomThree,

                         VolumnTest = entity.VolumnTest,
                         WaterTest = entity.WaterTest,
                         BottleTest = entity.BottleTest,
                         GasTest = entity.GasTest,
                         VacuumTest = entity.VacuumTest,
                         SyncTest = entity.SyncTest,
                         EvalDate = entity.EvalDate,
                     }
                     ).FirstOrDefault();
                if (gasinputView == null)
                {
                    gasinputView = new RegularInspectView();
                }
            }
            return gasinputView;
        }
        public RegularInspectView GetRegularInspectSingle(string id,string inspectNum)
        {
            RegularInspectView gasinputView;
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new RegularInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.ProjectName == id && x.InspectNum == inspectNum).ToList().
                     Select(entity => new RegularInspectView
                     {
                         Id = entity.Id,
                         ProjectName = entity.ProjectName,
                         InspectNum = entity.InspectNum,
                         InspectDes = entity.InspectDes,
                         TopOne = entity.TopOne,
                         TopTwo = entity.TopTwo,

                         BarrelOne = entity.BarrelOne,
                         BarrelTwo = entity.BarrelTwo,
                         BarrelThree = entity.BarrelThree,

                         BottomOne = entity.BottomOne,
                         BottomTwo = entity.BottomTwo,
                         BottomThree = entity.BottomThree,

                         VolumnTest = entity.VolumnTest,
                         WaterTest = entity.WaterTest,
                         BottleTest = entity.BottleTest,
                         GasTest = entity.GasTest,
                         VacuumTest = entity.VacuumTest,
                         SyncTest = entity.SyncTest,
                         EvalDate = entity.EvalDate,
                     }
                     ).FirstOrDefault();
                if (gasinputView == null)
                {
                    gasinputView = new RegularInspectView();
                }
            }
            return gasinputView;
        }
    }
}