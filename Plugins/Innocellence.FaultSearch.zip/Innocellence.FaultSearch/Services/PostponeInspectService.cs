﻿using Infrastructure.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;

namespace Innocellence.FaultSearch.Service
{
    public class PostponeInspectService : BaseService<PostponeInspectEntity>, IPostponeInspectService
    {
        private static List<PostponeInspectEntity> FEInfos = null;
        public List<PostponeInspectEntity> GetFEInfos()
        {
            if (FEInfos == null)
            {
                FEInfos = Repository.Entities.ToList();
            }
            return FEInfos;
        }


        public PostponeInspectService()
            : base("CAAdmin")
        {
        }

        public List<PostponeInspectView> GetPostponeQuerys()
        {
            return Repository.Entities.Select(x => new PostponeInspectView()
            {
                InspectNum = x.InspectNum,
                InspectDes = x.InspectDes
            }).Distinct().ToList();
        }
        public List<PostponeInspectView> GetPostPoneList(string Id)
        {
           
            return Repository.Entities.Where(x => x.ProjectName == Id && x.IsDeleted == false).Select(objView => new PostponeInspectView()
            {

                ProjectName = objView.ProjectName,
                InspectNum = objView.InspectNum,
                InspectDes = objView.InspectDes,
                UpperArcOne = objView.UpperArcOne,
                UpperArcTwo = objView.UpperArcTwo,
                UpperArcThree = objView.UpperArcThree,
                UpperArcFour = objView.UpperArcFour,

                UpperArcFive = objView.UpperArcFive,
                BarrelOne = objView.BarrelOne,
                BarrelTwo = objView.BarrelTwo,
                BarrelThree = objView.BarrelThree,
                BarrelFour = objView.BarrelFour,
                BottomOne = objView.BottomOne,
                BottomTwo = objView.BottomTwo,

                BottomThree = objView.BottomThree,
                BottomFour = objView.BottomFour,
                BottomFive = objView.BottomFive,
                VolumnTest = objView.VolumnTest,
                WaterTest = objView.WaterTest,
                BottleTest = objView.BottleTest,
                GasTest = objView.GasTest,
                SyncTest = objView.SyncTest,
                EvalDate = objView.EvalDate,
            }).Distinct().ToList();
        }
        public IList<PostponeInspectEntity> QueryList(Expression<Func<PostponeInspectEntity, bool>> func)
        {
            return Repository.Entities.Where(func).ToList();
        }


        public List<T> GetListByDate<T>(Expression<Func<PostponeInspectEntity, bool>> predicate) where T : Infrastructure.Core.IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public List<T> GetList<T>(Expression<Func<PostponeInspectEntity, bool>> predicate) where T : IViewModel, new()
        {
            var lst = Repository.Entities.Where(predicate).ToList().Select(n => (T)(new T().ConvertAPIModel(n))).ToList();
            return lst;
        }
        public override int InsertView<T>(T objModalSrc)
        {
            int iRet;
            var objView = objModalSrc as PostponeInspectView;
            var entity = new PostponeInspectEntity()
            {
                ProjectName = objView.ProjectName,
                InspectNum = objView.InspectNum,
                InspectDes = objView.InspectDes,
                UpperArcOne = objView.UpperArcOne,
                UpperArcTwo = objView.UpperArcTwo,
                UpperArcThree = objView.UpperArcThree,
                UpperArcFour = objView.UpperArcFour,

                UpperArcFive = objView.UpperArcFive,
                BarrelOne = objView.BarrelOne,
                BarrelTwo = objView.BarrelTwo,
                BarrelThree = objView.BarrelThree,
                BarrelFour = objView.BarrelFour,
                BottomOne = objView.BottomOne,
                BottomTwo = objView.BottomTwo,

                BottomThree = objView.BottomThree,
                BottomFour = objView.BottomFour,
                BottomFive = objView.BottomFive,
                VolumnTest = objView.VolumnTest,
                WaterTest = objView.WaterTest,
                BottleTest = objView.BottleTest,
                GasTest = objView.GasTest,
                SyncTest = objView.SyncTest,
                EvalDate = objView.EvalDate,
            };
            if (objView == null)
            {
                return -1;
            }
            iRet = Repository.Insert(entity);

            return iRet;
        }

        public override int UpdateView<T>(T objModalSrc)
        {
            int iRet;
            var objModal = objModalSrc as PostponeInspectView;

            if (objModal == null)
            {
                return -1;
            }
            int Id = objModal.Id;

            iRet = base.UpdateView(objModal);

            return iRet;
        }
        public PostponeInspectView GetPostponeDetail(string id)
        {
            PostponeInspectView gasinputView;
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new PostponeInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.ProjectName == id).ToList()
                   .Select(entity => new PostponeInspectView()
                   {
                       Id = entity.Id,
                       ProjectName = entity.ProjectName,
                       InspectNum = entity.InspectNum,
                       InspectDes = entity.InspectDes,
                       UpperArcOne = entity.UpperArcOne,
                       UpperArcTwo = entity.UpperArcTwo,
                       UpperArcThree = entity.UpperArcThree,
                       UpperArcFour = entity.UpperArcFour,
                       UpperArcFive = entity.UpperArcFive,

                       BarrelOne = entity.BarrelOne,
                       BarrelTwo = entity.BarrelTwo,
                       BarrelThree = entity.BarrelThree,
                       BarrelFour = entity.BarrelFour,

                       BottomOne = entity.BottomOne,
                       BottomTwo = entity.BottomTwo,
                       BottomThree = entity.BottomThree,
                       BottomFour = entity.BottomFour,
                       BottomFive = entity.BottomFive,

                       VolumnTest = entity.VolumnTest,
                       WaterTest = entity.WaterTest,
                       BottleTest = entity.BottleTest,
                       GasTest = entity.GasTest,
                       VacuumTest = entity.VacuumTest,
                       SyncTest = entity.SyncTest,
                       EvalDate = entity.EvalDate
                   }).FirstOrDefault();
                if (gasinputView == null)
                {
                    gasinputView = new PostponeInspectView();
                }
            }
            return gasinputView;
        }
        public PostponeInspectView GetPostponeSingle(string id, string inspectNum)
        {
            PostponeInspectView gasinputView;
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                gasinputView = new PostponeInspectView();
            }
            else
            {
                gasinputView = Repository.Entities.Where(x => x.ProjectName == id && x.InspectNum == inspectNum).ToList()
                   .Select(entity => new PostponeInspectView()
                   {
                       Id = entity.Id,
                       ProjectName = entity.ProjectName,
                       InspectNum = entity.InspectNum,
                       InspectDes = entity.InspectDes,
                       UpperArcOne = entity.UpperArcOne,
                       UpperArcTwo = entity.UpperArcTwo,
                       UpperArcThree = entity.UpperArcThree,
                       UpperArcFour = entity.UpperArcFour,
                       UpperArcFive = entity.UpperArcFive,

                       BarrelOne = entity.BarrelOne,
                       BarrelTwo = entity.BarrelTwo,
                       BarrelThree = entity.BarrelThree,
                       BarrelFour = entity.BarrelFour,

                       BottomOne = entity.BottomOne,
                       BottomTwo = entity.BottomTwo,
                       BottomThree = entity.BottomThree,
                       BottomFour = entity.BottomFour,
                       BottomFive = entity.BottomFive,

                       VolumnTest = entity.VolumnTest,
                       WaterTest = entity.WaterTest,
                       BottleTest = entity.BottleTest,
                       GasTest = entity.GasTest,
                       VacuumTest = entity.VacuumTest,
                       SyncTest = entity.SyncTest,
                       EvalDate = entity.EvalDate
                   }).FirstOrDefault();
                if (gasinputView == null)
                {
                    gasinputView = new PostponeInspectView();
                }
            }
            return gasinputView;
        }
    }
}