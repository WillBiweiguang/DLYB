﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;

namespace Innocellence.FaultSearch.Services
{
    public interface IFaultSearchService : IDependency, IBaseService<FaultSearchEntity>
    {
        IList<FaultSearchEntity> QueryList(Expression<Func<FaultSearchEntity, bool>> func);
        List<FaultSearchEntity> GetFEInfos();
        List<FaultSearchView> GetFailureQuerys();
        List<T> GetList<T>(Expression<Func<FaultSearchEntity, bool>> predicate) where T : IViewModel, new();
    }
}
