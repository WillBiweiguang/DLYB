﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;

namespace Innocellence.FaultSearch.Services
{
    public interface IAnsysTypeService : IDependency, IBaseService<AnsysTypeEntity>
    {
        IList<AnsysTypeEntity> QueryList(Expression<Func<AnsysTypeEntity, bool>> func);
        List<AnsysTypeEntity> GetFEInfos();
        List<T> GetList<T>(Expression<Func<AnsysTypeEntity, bool>> predicate) where T : IViewModel, new();
        List<AnsysTypeView> GetBasicQuerys();
        AnsysTypeView GetImagesDetail(string id, string category);
    }
}
