﻿using System;
using System.Collections.Generic;
using Infrastructure.Core;
using System.Linq.Expressions;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Model;

namespace Innocellence.FaultSearch.Services
{
    public interface IFaultModeService : IDependency, IBaseService<FaultModeEntity>
    {
        IList<FaultModeEntity> QueryList(Expression<Func<FaultModeEntity, bool>> func);
        List<FaultModeEntity> GetFEInfos();
        List<FaultModeView> GetFailureQuerys();
        List<T> GetList<T>(Expression<Func<FaultModeEntity, bool>> predicate) where T : IViewModel, new();
    }
}
