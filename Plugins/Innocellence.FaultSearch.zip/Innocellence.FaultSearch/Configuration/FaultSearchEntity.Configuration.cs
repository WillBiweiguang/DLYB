﻿using Infrastructure.Core.Data;
using Innocellence.FaultSearch.Model;

namespace Innocellence.FaultSearch.Configuration
{
    public class FaultSearchEntityConfiguration : EntityConfigurationBase<FaultSearchEntity, int>
    {
        public FaultSearchEntityConfiguration()
        {
            ToTable("FaultSearch");
        }
    }
    public class FaultModeEntityConfiguration : EntityConfigurationBase<FaultModeEntity, int>
    {
        public FaultModeEntityConfiguration()
        {
            ToTable("FaultMode");
        }
    }
    public class GasInputEntityConfiguration : EntityConfigurationBase<GasInputEntity, int>
    {
        public GasInputEntityConfiguration()
        {
            ToTable("GasInput");
        }
    }
    public class DetectInputEntityConfiguration : EntityConfigurationBase<DetectInputEntity, int>
    {
        public DetectInputEntityConfiguration()
        {
            ToTable("DetectInput");
        }
    }
    public class DetectSubInputEntityConfiguration : EntityConfigurationBase<DetectSubInputEntity, int>
    {
        public DetectSubInputEntityConfiguration()
        {
            ToTable("DetectSubInput");
        }
    }
    public class PostponeInspectEntityConfiguration : EntityConfigurationBase<PostponeInspectEntity, int>
    {
        public PostponeInspectEntityConfiguration()
        {
            ToTable("PostponeInspect");
        }
    }
    public class RegularInspectEntityConfiguration : EntityConfigurationBase<RegularInspectEntity, int>
    {
        public RegularInspectEntityConfiguration()
        {
            ToTable("RegularInspect");
        }
    }
    public class AnsysTypeEntityConfiguration : EntityConfigurationBase<AnsysTypeEntity, int>
    {
        public AnsysTypeEntityConfiguration()
        {
            ToTable("AnsysType");
        }
    }
}
