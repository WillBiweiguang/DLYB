﻿using System;
using System.Collections.Generic;
using System.Linq;
using Infrastructure.Core;

namespace Innocellence.FaultSearch.Model
{
    public class DetectSubInputEntity : EntityBase<int>
    {
       
        public override int Id { get; set; }
        public string DetectNum { get; set; }
        public string ProjectName{ get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
    }
}