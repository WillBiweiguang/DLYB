﻿using System;
using System.Collections.Generic;
using System.Linq;
using Infrastructure.Core;

namespace Innocellence.FaultSearch.Model
{
    public class FaultSearchEntity : EntityBase<int>
    {
        public override int Id { get; set; }
        public string ProjectName { get; set; }
        public string FailureClass { get; set; }
        public string FailureMode { get; set; }
        public string FailureResult { get; set; }
        public string Severity { get; set; }
        public string Frequency { get; set; }
        public string Detec { get; set; }
        public string RPN { get; set; }
        public string RiskLevel { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
    }
}