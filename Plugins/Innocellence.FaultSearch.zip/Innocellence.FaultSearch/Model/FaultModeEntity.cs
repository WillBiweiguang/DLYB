﻿using System;
using System.Collections.Generic;
using System.Linq;
using Infrastructure.Core;

namespace Innocellence.FaultSearch.Model
{
    public class FaultModeEntity : EntityBase<int>
    {
        public override int Id { get; set; }
        public string ProjectName { get; set; }
        public string FailureResult { get; set; }
        public string ReasonOne { get; set; }
        public string ReasonTwo { get; set; }
        public string ReasonThree { get; set; }
        public string ReasonFour { get; set; }
        public string ReasonFive { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
    }
}