﻿using System;
using System.Collections.Generic;
using System.Linq;
using Infrastructure.Core;

namespace Innocellence.FaultSearch.Model
{
    public class GasInputEntity : EntityBase<int>
    {
        public override int Id { get; set; }
        public string ProjectName { get; set; }
        public string UseCompany { get; set; }
        public string MadeCompany { get; set; }
        public string BottleNum { get; set; }
        public string Volume { get; set; }
        public DateTime? MadeTime { get; set; }
        public string DesignWall { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
    }
}