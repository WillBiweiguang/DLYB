﻿using System;
using System.Collections.Generic;
using System.Linq;
using Infrastructure.Core;

namespace Innocellence.FaultSearch.Model
{
    public class RegularInspectEntity : EntityBase<int>
    {
    
        public override int Id { get; set; }
        public string ProjectName { get; set; }
        public string InspectNum { get; set; }
        public string InspectDes { get; set; }
        public string TopOne { get; set; }
        public string TopTwo { get; set; }
        public string BarrelOne { get; set; }
        public string BarrelTwo { get; set; }
        public string BarrelThree { get; set; }
        public string BottomOne { get; set; }
        public string BottomTwo { get; set; }
        public string BottomThree { get; set; }
        public string VolumnTest { get; set; }
        public string WaterTest { get; set; }
        public string BottleTest { get; set; }
        public string GasTest { get; set; }
        public string VacuumTest { get; set; }
        public string SyncTest { get; set; }
        public DateTime? EvalDate { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
    }
}