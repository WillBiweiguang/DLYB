﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;


namespace Innocellence.FaultSearch.Controllers
{
    public class BTestController : AdminBaseController<FaultSearchEntity, FaultSearchView>
    {
        private IFaultSearchService _fautService = new FaultSearchService();

        public BTestController(IFaultSearchService objService)
            : base(objService)
        {
            _fautService = objService;
        }

        public override ActionResult Index()
        {
            return View();
        }
      
    }
}