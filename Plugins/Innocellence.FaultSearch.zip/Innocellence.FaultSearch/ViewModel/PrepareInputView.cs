﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.ComponentModel;

namespace Innocellence.FaultSearch.ViewModel
{
    public partial class PrepareInputView : IViewModel
    {
        public int Id { get; set; }
        [Description("项目名称")]
        public string ProjectName { get; set; }

        [Description("检验分类")]
        public string DetectCategory { get; set; }
        [Description("序号")]
        public string Number { get; set; }
        [Description("内容")]
        public string ContentText { get; set; }

        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (PrepareInputEntity)obj;
            Id = entity.Id;
            ProjectName = entity.ProjectName;
            DetectCategory = entity.DetectCategory;
            Number = entity.Number;
            ContentText = entity.ContentText;
            return this;
        }
    }
}
