﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.ComponentModel;
using Innocellence.CA.ModelsView;
using System.Collections.Generic;
namespace Innocellence.FaultSearch.ViewModel
{
    public partial class AnsysTypeView : IViewModel
    {
        public int Id { get; set; }
        [Description("项目名称")]
        public string ProjectName { get; set; }
        [Description("类型")]
        public string Category { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public string ImageIdList { get; set; }
        public List<QuestionImagesView> QuestionImages { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (AnsysTypeEntity)obj;
            Id = entity.Id;
            ProjectName = entity.ProjectName;
            Category = entity.Category;
            return this;
        }
    }
}
