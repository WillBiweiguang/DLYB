﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.ComponentModel;

namespace Innocellence.FaultSearch.ViewModel
{
    public partial class DetectInputView : IViewModel
    {
        public int Id { get; set; }
       
        [Description("标准")]
        public string ContentText { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (DetectInputEntity)obj;
            Id = entity.Id;
            ContentText = entity.ContentText;
            return this;
        }
    }
}
