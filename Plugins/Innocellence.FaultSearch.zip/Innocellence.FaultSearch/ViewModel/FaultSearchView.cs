﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.ComponentModel;

namespace Innocellence.FaultSearch.ViewModel
{
    public partial class FaultSearchView : IViewModel
    {
        public int Id { get; set; }
        [Description("项目名称")]
        public string ProjectName { get; set; }
        [DescriptionAttribute("失效分类")]
        public string FailureClass { get; set; }
        [DescriptionAttribute("失效模式")]
        public string FailureMode { get; set; }
        [DescriptionAttribute("失效后果")]
        public string FailureResult { get; set; }
        [DescriptionAttribute("严重度")]
        public string Severity { get; set; }
        [DescriptionAttribute("频度")]
        public string Frequency { get; set; }
        [DescriptionAttribute("探测度")]
        public string Detec { get; set; }

        public string RPN { get; set; }
        [DescriptionAttribute("风险等级")]
        public string RiskLevel { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (FaultSearchEntity)obj;
            Id = entity.Id;
            ProjectName = entity.ProjectName;
            FailureClass = entity.FailureClass;
            FailureMode = entity.FailureMode;
            FailureResult = entity.FailureResult;
            Severity = entity.Severity;
            Frequency = entity.Frequency;
            Detec = entity.Detec;
            RPN = entity.RPN;
            RiskLevel = entity.RiskLevel;
            return this;
        }
    }
}
