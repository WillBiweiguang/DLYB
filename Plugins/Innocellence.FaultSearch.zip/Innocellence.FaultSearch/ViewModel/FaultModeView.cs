﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.ComponentModel;

namespace Innocellence.FaultSearch.ViewModel
{
    public partial class FaultModeView : IViewModel
    {
        public int Id { get; set; }
        [Description("项目名称")]
        public string ProjectName { get; set; }
        [DescriptionAttribute("事故结果")]
        public string FailureResult { get; set; }
        [DescriptionAttribute("原因分级1")]
        public string ReasonOne { get; set; }
        [DescriptionAttribute("原因分级2")]
        public string ReasonTwo { get; set; }
        [DescriptionAttribute("原因分级3")]
        public string ReasonThree { get; set; }
        [DescriptionAttribute("原因分级4")]
        public string ReasonFour { get; set; }
        [DescriptionAttribute("原因分级5")]
        public string ReasonFive { get; set; }

        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (FaultModeEntity)obj;
            Id = entity.Id;
            ProjectName = entity.ProjectName;
            ReasonOne = entity.ReasonOne;
            ReasonTwo = entity.ReasonTwo;
            FailureResult = entity.FailureResult;
            ReasonThree = entity.ReasonThree;
            ReasonFour = entity.ReasonFour;
            ReasonFive = entity.ReasonFive;
            return this;
        }
    }
}
