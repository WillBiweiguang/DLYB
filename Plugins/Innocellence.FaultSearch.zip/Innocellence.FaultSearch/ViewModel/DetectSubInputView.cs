﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.ComponentModel;

namespace Innocellence.FaultSearch.ViewModel
{
    public partial class DetectSubInputView : IViewModel
    {
        public int Id { get; set; }
       
        [Description("检验编号")]
        public string DetectNum { get; set; }
        [Description("气瓶编号")]
        public string ProjectName { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (DetectSubInputEntity)obj;
            Id = entity.Id;
            DetectNum = entity.DetectNum;
            ProjectName = ProjectName;
            return this;
        }
    }
}
