﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.ComponentModel;

namespace Innocellence.FaultSearch.ViewModel
{
    public partial class RegularInspectView : IViewModel
    {
        public int Id { get; set; }
        [Description("项目名称")]
        public string ProjectName { get; set; }
        [Description("检验编号")]
        public string InspectNum { get; set; }
        [Description("外观检查")]
        public string InspectDes { get; set; }
        [Description("顶部1")]
        public string TopOne { get; set; }
        [Description("顶部2")]
        public string TopTwo { get; set; }
        [Description("筒体1")]
        public string BarrelOne { get; set; }
        [Description("筒体2")]
        public string BarrelTwo { get; set; }
        [Description("筒体3")]
        public string BarrelThree { get; set; }
        [Description("底部1")]
        public string BottomOne { get; set; }
        [Description("底部2")]
        public string BottomTwo { get; set; }
        [Description("底部3")]
        public string BottomThree { get; set; }
        [Description("容积测定")]
        public string VolumnTest { get; set; }
        [Description("水压试验")]
        public string WaterTest { get; set; }
        [Description("瓶阀检验")]
        public string BottleTest { get; set; }
        [Description("气密性试验")]
        public string GasTest { get; set; }
        [Description("真空度")]
        public string VacuumTest { get; set; }
        [Description("综合评定")]
        public string SyncTest { get; set; }
        [Description("评定日期")]
        public DateTime? EvalDate { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (RegularInspectEntity)obj;
            Id = entity.Id;
            ProjectName = entity.ProjectName;
            InspectNum = entity.InspectNum;
            InspectDes = entity.InspectDes;
            TopOne = entity.TopOne;
            TopTwo = entity.TopTwo;

            BarrelOne = entity.BarrelOne;
            BarrelTwo = entity.BarrelTwo;
            BarrelThree = entity.BarrelThree;

            BottomOne = entity.BottomOne;
            BottomTwo = entity.BottomTwo;
            BottomThree = entity.BottomThree;

            VolumnTest = entity.VolumnTest;
            WaterTest = entity.WaterTest;
            BottleTest = entity.BottleTest;
            GasTest = entity.GasTest;
            VacuumTest = entity.VacuumTest;
            SyncTest = entity.SyncTest;
            EvalDate = entity.EvalDate;
            return this;
        }
    }
}
