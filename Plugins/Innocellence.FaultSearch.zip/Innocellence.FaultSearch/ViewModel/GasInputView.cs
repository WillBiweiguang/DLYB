﻿using Infrastructure.Core;
using Innocellence.FaultSearch.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Innocellence.FaultSearch.ViewModel
{
    public partial class GasInputView : IViewModel
    {
        public int Id { get; set; }
        [Description("气瓶编号")]
        public string ProjectName { get; set; }
        [Description("使用单位")]
        public string UseCompany { get; set; }
        [Description("制造单位")]
        public string MadeCompany { get; set; }
        [Description("气瓶型号")]
        public string BottleNum { get; set; }

        [Description("公称容积")]
        public string Volume { get; set; }
        [Description("制造年月")]
        public DateTime? MadeTime { get; set; }
        [Description("设计壁厚")]
        public string DesignWall { get; set; }
        //检验编号
        public string CheckNum { get; set; }
        //检验标准
        public string CheckStandard { get; set; }
        //是否合格
        public string MeetStandard { get; set; }
        public string UpdatedUserId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedUserId { get; set; }
        public Boolean? IsDeleted { get; set; }
        public DetectInputView DI { get; set; }
        public DetectSubInputView DSI { get; set; }
        public PostponeInspectView PI { get; set; }
        public RegularInspectView RI { get; set; }
        public List<PostponeInspectView> PIList { get; set; }
        public List<RegularInspectView> RIList { get; set; }
        public AnsysTypeView AT { get; set; }
        public IViewModel ConvertAPIModel(object obj)
        {
            var entity = (GasInputEntity)obj;
            Id = entity.Id;
            ProjectName = entity.ProjectName;
            UseCompany = entity.UseCompany;
            MadeCompany = entity.MadeCompany;
            BottleNum = entity.BottleNum;
            Volume = entity.Volume;
            MadeTime = entity.MadeTime;
            DesignWall = entity.DesignWall;
            return this;
        }
    }
}
