﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;


namespace Innocellence.FaultSearch.Controllers
{
    public class BRiskRateController : AdminBaseController<FaultSearchEntity, FaultSearchView>
    {
        private IFaultSearchService _objService = new FaultSearchService();

        public BRiskRateController(IFaultSearchService objService)
            : base(objService)
        {
            _objService = objService;
        }

        public override ActionResult Index()
        {
         
            return View();
        }
       
        public ActionResult Previous()
        {

            return Redirect("~/faultsearch/BBottleInspect/index");
        }

        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(FaultSearchView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            InsertOrUpdate(objModal, Id);

            return Json(doJson(null), JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(FaultSearchView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _BaseService.InsertView(objModal);
            }
            else
            {
                _BaseService.UpdateView(objModal);
            }
        }
       
    }
}