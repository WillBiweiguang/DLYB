﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using EntityFramework.Extensions;
using Innocellence.CA.Contracts.CommonEntity;

namespace Innocellence.FaultSearch.Controllers
{
    //检测内容录入
    public class BDetectInputController : AdminBaseController<DetectInputEntity, DetectInputView>
    {
        private IDetectInputService _fautService = new DetectInputService();
        private IDetectSubInputService _detectService = new DetectSubInputService();
        public BDetectInputController(IDetectInputService objService)
            : base(objService)
        {
            _fautService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BBottleBasic/index";
            //var pid = Request["pid"];
            //var obj = _detectService.Repository.Entities.Where(x => x.ProjectName == pid).ToList().Select(x => x.DetectNum).FirstOrDefault();
            //if (!string.IsNullOrEmpty(obj) || obj != "0")
            //{
            //    ViewBag.detect = obj;
            //}
            return View();
        }
        public ActionResult ReadIndex()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BBottleBasic/Readindex";
            return View();
        }

        public ActionResult Ansys()
        {
            var id = Request["pid"];
            var isopen = Request["isopen"];
            var isnew = Request["isnew"];
            if (isopen == "1")
            {
                return Redirect("~/faultsearch/BUpload/Readindex?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            else if (isopen == "2" || isopen == "0")
            {
                return Redirect("~/faultsearch/BUpload/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            return Redirect("~/faultsearch/BUpload/index");
        }
        public override ActionResult Next()
        {
            string symbol = Request["symble"];
            var id = Request["pid"];
            var isopen = Request["isopen"];
            var isnew = Request["isnew"];
            if (symbol == "1" && isopen == "1")
            {
                return Redirect("~/faultsearch/BRegularInspect/Readindex?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            //新建
            else if (symbol == "1" && ( isopen == "0"))
            {
                return Redirect("~/faultsearch/BRegularInspect/Checkindex?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            //打开编辑
            else if (symbol == "1" && (isopen == "2"))
            {
                return Redirect("~/faultsearch/BRegularInspect/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            else if (symbol == "2" && isopen == "1")
            {
                return Redirect("~/faultsearch/BPostponeInput/Readindex?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            //新建
            else if (symbol == "2" && ( isopen == "0"))
            {
                return Redirect("~/faultsearch/BPostponeInput/Checkindex?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            //打开编辑
            else if (symbol == "2" && (isopen == "2" ))
            {
                return Redirect("~/faultsearch/BPostponeInput/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            return null;

        }
        public override ActionResult Previous()
        {
            string symbol = Request["symble"];
            var id = Request["pid"];
            var isopen = Request["isopen"];
            var isnew = Request["isnew"];
           
            //新建
             if (isopen == "0")
            {
                return Redirect("~/faultsearch/BBottleBasic/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            //打开编辑
            else if (isopen == "2")
            {
                return Redirect("~/faultsearch/BBasicOpen/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
         
            return null;

        }
        [HttpPost]
        public ActionResult ResultTemp(string id)
        {
            var temp = _detectService.Repository.Entities.Where(x => x.ProjectName == id).ToList().Select(x => x.DetectNum).FirstOrDefault();
            if (!string.IsNullOrEmpty(temp) || temp != "0")
            {
                return Json(new Result<String> { Status = 200, Data = temp }, JsonRequestBehavior.AllowGet);
            }
            return Json(new Result<int> { Status = 999 }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult Create(DetectSubInputView objModal)
        {
           
            objModal.ProjectName = Request["pid"];
            objModal.DetectNum = Request["symble"];
           
            var num = _detectService.Repository.Entities.Where(x => x.ProjectName == objModal.ProjectName)
                .ToList().Select(x => x.Id).FirstOrDefault();
           
            if (num== 0)
            {
                _detectService.InsertView(objModal);
            }
            else
            {
                var num1 = num.ToString();
                _detectService.Repository.Entities.Where(x => x.ProjectName == num1)
                    .Update(x => new DetectSubInputEntity { DetectNum = objModal.DetectNum }); ;
            }

            return Json(new { rtnId = objModal.Id, str = "Insert Success." });

        }

        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(DetectInputView objModal, string Id)
        {
            //验证错误

            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            InsertOrUpdate(objModal, Id);

            return Json(new { rtnId = objModal.Id, str = "Insert Success." });
        }

        protected void InsertOrUpdate(DetectInputView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _fautService.InsertView(objModal);
            }
            else
            {
                _fautService.UpdateView(objModal);
            }
        }

    }
}