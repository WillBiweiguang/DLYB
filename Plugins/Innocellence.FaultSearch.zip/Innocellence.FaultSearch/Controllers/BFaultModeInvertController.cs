﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;


namespace Innocellence.FaultSearch.Controllers
{
    public class BFaultModeInvertController : AdminBaseController<FaultModeEntity, FaultModeView>
    {
        private IFaultModeService _fautService = new FaultModeService();

        public BFaultModeInvertController(IFaultModeService objService)
            : base(objService)
        {
            _fautService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.list = _fautService.GetFailureQuerys();
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BFaultMode/index";
            ViewBag.nexturl = "~/faultsearch/BSeverityTest/index";
            return View();
        }
        public ActionResult ReadIndex()
        {
            ViewBag.list = _fautService.GetFailureQuerys();
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BFaultMode/ReadIndex";
            ViewBag.nexturl = "~/faultsearch/BSeverityTest/ReadIndex";
            return View();
        }
        //public ActionResult Previous()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BFaultMode/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}
        //public ActionResult Next()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BSeverityTest/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}
        public ActionResult GetFaultModeQuerys()
        {
            var list = _fautService.GetFailureQuerys();

            return Json(list, JsonRequestBehavior.AllowGet);
        }

        public override List<FaultModeView> GetListEx(Expression<Func<FaultModeEntity, bool>> predicate, PageCondition ConPage)
        {

            string strFive = Request["ReasonFive"];

            if (!string.IsNullOrEmpty(strFive))
            {
                predicate = predicate.AndAlso(a => a.ReasonFive == strFive);
            }
            predicate = predicate.AndAlso(a => a.IsDeleted != true);
            //TODO:
            //predicate = predicate.AndAlso(a => a.AppId == AppId);

            var q = _BaseService.GetList<FaultModeView>(predicate, ConPage).ToList();

            return q;
        }
        public override ActionResult Edit(string id)
        {
           
            var obj = GetObject(id);

            return View(obj);
        }

        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(FaultModeView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            InsertOrUpdate(objModal, Id);

            return Json(doJson(null), JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(FaultModeView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {

                _objService.InsertView(objModal);
            }
            else
            {
                _objService.UpdateView(objModal);
            }
        }
        public override ActionResult Export()
        {
            string strFive = Request["ReasonFive"];

            Expression<Func<FaultModeEntity, bool>> predicate = x => x.Id > 0;


            if (!string.IsNullOrEmpty(strFive))
            {
                predicate = predicate.AndAlso(a => a.ReasonFour == strFive);
            }
            predicate = predicate.AndAlso(a => a.IsDeleted != true);
            var reportList = _fautService.GetList<FaultModeView>(predicate).OrderByDescending(x => x.Id).ToList();

            return ExportToCsv(reportList);
        }

        private ActionResult ExportToCsv(List<FaultModeView> list)
        {
            string[] headLine = { "Id", "FailureResult", "ReasonOne", "ReasonTwo", "ReasonThree", "ReasonFour", "ReasonFive" };
            var csv = new CsvSerializer<FaultModeView> { UseLineNumbers = false };
            var sRet = csv.SerializeStream(list, headLine);
            string fileName = "FaultSModeInvert_" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".csv";
            return File(sRet, "text/comma-separated-values", fileName);
        }
    }
}