﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;


namespace Innocellence.FaultSearch.Controllers
{
    public class BFaultModeController : AdminBaseController<FaultModeEntity, FaultModeView>
    {
        private IFaultModeService _fautService = new FaultModeService();

        public BFaultModeController(IFaultModeService objService)
            : base(objService)
        {
            _fautService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.list = _fautService.GetFailureQuerys();
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BSearchSelect/index";
            ViewBag.nexturl = "~/faultsearch/BFaultModeInvert/index";
            return View();
        }
        public  ActionResult ReadIndex()
        {
            ViewBag.list = _fautService.GetFailureQuerys();
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BSearchSelect/ReadIndex";
            ViewBag.nexturl = "~/faultsearch/BFaultModeInvert/ReadIndex";
            return View();
        }
        //public ActionResult Previous()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BSearchSelect/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}
        //public ActionResult Next()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BFaultModeInvert/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}
        public ActionResult GetFaultModeQuerys()
        {
            var list = _fautService.GetFailureQuerys();

            return Json(list, JsonRequestBehavior.AllowGet);
        }

        public override List<FaultModeView> GetListEx(Expression<Func<FaultModeEntity, bool>> predicate, PageCondition ConPage)
        {
            string strClass = Request["FailureResult"];
            string strMode = Request["ReasonOne"];
            string strTwo = Request["ReasonTwo"];
            string strThree = Request["ReasonThree"];
            string strFour = Request["ReasonFour"];
            if (!string.IsNullOrEmpty(strClass))
            {
                predicate = predicate.AndAlso(a => a.FailureResult == strClass);
            }

            if (!string.IsNullOrEmpty(strMode))
            {
                predicate = predicate.AndAlso(a => a.ReasonOne == strMode);
            }
            if (!string.IsNullOrEmpty(strTwo))
            {
                predicate = predicate.AndAlso(a => a.ReasonTwo == strTwo);
            }

            if (!string.IsNullOrEmpty(strThree))
            {
                predicate = predicate.AndAlso(a => a.ReasonThree == strThree);
            }
            if (!string.IsNullOrEmpty(strFour))
            {
                predicate = predicate.AndAlso(a => a.ReasonFour == strFour);
            }
            predicate = predicate.AndAlso(a => a.IsDeleted != true);
            //TODO:
            //predicate = predicate.AndAlso(a => a.AppId == AppId);

            var q = _BaseService.GetList<FaultModeView>(predicate, ConPage).ToList();

            return q;
        }
        public override ActionResult Edit(string id)
        {
           
            var obj = GetObject(id);

            return View(obj);
        }

        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(FaultModeView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            InsertOrUpdate(objModal, Id);

            return Json(doJson(null), JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(FaultModeView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {

                _objService.InsertView(objModal);
            }
            else
            {
                _objService.UpdateView(objModal);
            }
        }
        public override ActionResult Export()
        {
            string strClass = Request["FailureResult"];
            string strMode = Request["ReasonOne"];
            string strTwo = Request["ReasonTwo"];
            string strThree = Request["ReasonThree"];
            string strFour = Request["ReasonFour"];

            Expression<Func<FaultModeEntity, bool>> predicate = x => x.Id > 0;

            if (!string.IsNullOrEmpty(strClass))
            {
                predicate = predicate.AndAlso(a => a.FailureResult == strClass);
            }

            if (!string.IsNullOrEmpty(strMode))
            {
                predicate = predicate.AndAlso(a => a.ReasonOne == strMode);
            }
            if (!string.IsNullOrEmpty(strTwo))
            {
                predicate = predicate.AndAlso(a => a.ReasonTwo == strTwo);
            }

            if (!string.IsNullOrEmpty(strThree))
            {
                predicate = predicate.AndAlso(a => a.ReasonThree == strThree);
            }
            if (!string.IsNullOrEmpty(strFour))
            {
                predicate = predicate.AndAlso(a => a.ReasonFour == strFour);
            }
            predicate = predicate.AndAlso(a => a.IsDeleted != true);
            var reportList = _fautService.GetList<FaultModeView>(predicate).OrderByDescending(x => x.Id).ToList();

            return ExportToCsv(reportList);
        }

        private ActionResult ExportToCsv(List<FaultModeView> list)
        {
            string[] headLine = { "Id", "FailureResult", "ReasonOne", "ReasonTwo", "ReasonThree", "ReasonFour", "ReasonFive" };
            var csv = new CsvSerializer<FaultModeView> { UseLineNumbers = false };
            var sRet = csv.SerializeStream(list, headLine);
            string fileName = "FaultSMode_" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".csv";
            return File(sRet, "text/comma-separated-values", fileName);
        }
    }
}