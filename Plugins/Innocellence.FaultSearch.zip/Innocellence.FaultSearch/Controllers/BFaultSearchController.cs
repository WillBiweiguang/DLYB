﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;


namespace Innocellence.FaultSearch.Controllers
{
    public class BFaultSearchController : AdminBaseController<FaultSearchEntity, FaultSearchView>
    {
        private IFaultSearchService _fautService = new FaultSearchService();

        public BFaultSearchController(IFaultSearchService objService)
            : base(objService)
        {
            _fautService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.list = _fautService.GetFailureQuerys();
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; 
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BRiskTest/index";
            ViewBag.nexturl = "~/faultsearch/BGasInput/index";
            return View();
        }
        public ActionResult ReadIndex()
        {
            ViewBag.list = _fautService.GetFailureQuerys();
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BRiskTest/ReadIndex";
            ViewBag.nexturl = "~/faultsearch/BGasInput/ReadIndex";
            return View();
        }
        //public ActionResult Previous()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BRiskTest/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}

        public override ActionResult Next()
        {
            var id = Request["pid"];
            var isopen = Request["isopen"];
            var isnew = Request["isnew"];
            //打开只读
            if(isopen=="1"){
                return Redirect("~/faultsearch/BGasInput/Readindex?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
            else if (isopen == "2" || isopen == "0")
            {
                return Redirect("~/faultsearch/BGasInput/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
            }
           
           return Redirect("~/faultsearch/BGasInput/index");
        }
        public ActionResult GetFaultSearchQuerys()
        {
            var list = _fautService.GetFailureQuerys();

            return Json(list, JsonRequestBehavior.AllowGet);
        }

        public override List<FaultSearchView> GetListEx(Expression<Func<FaultSearchEntity, bool>> predicate, PageCondition ConPage)
        {
            string strClass = Request["FailureClass"];
            string strMode = Request["FailureMode"];

            if (!string.IsNullOrEmpty(strClass))
            {
                predicate = predicate.AndAlso(a => a.FailureClass==strClass);
            }

            if (!string.IsNullOrEmpty(strMode))
            {
                predicate = predicate.AndAlso(a => a.FailureMode==strMode);
            }
            predicate = predicate.AndAlso(a => a.IsDeleted != true);
            //TODO:
            //predicate = predicate.AndAlso(a => a.AppId == AppId);

            var q = _BaseService.GetList<FaultSearchView>(predicate, ConPage).ToList();

            return q;
        }
        public override ActionResult Edit(string id)
        {
           
            var obj = GetObject(id);

            return View(obj);
        }

        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(FaultSearchView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            InsertOrUpdate(objModal, Id);

            return Json(doJson(null), JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(FaultSearchView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _BaseService.InsertView(objModal);
            }
            else
            {
                _BaseService.UpdateView(objModal);
            }
        }

        public override ActionResult Export()
        {
            string strClass = Request["FailureClass"];
            string strMode = Request["FailureMode"];

            Expression<Func<FaultSearchEntity, bool>> predicate = x => x.Id > 0;

            if (!string.IsNullOrEmpty(strClass))
            {
                predicate = predicate.AndAlso(a => a.FailureClass.Equals(strClass, StringComparison.CurrentCultureIgnoreCase));
            }

            if (!string.IsNullOrEmpty(strMode))
            {
                predicate = predicate.AndAlso(a => a.FailureMode.Contains(strMode));
            }
            predicate = predicate.AndAlso(a => a.IsDeleted != true);
            var reportList = _fautService.GetList<FaultSearchView>(predicate).OrderByDescending(x => x.Id).ToList();

            return ExportToCsv(reportList);
        }

        private ActionResult ExportToCsv(List<FaultSearchView> list)
        {
            string[] headLine = { "Id", "FailureClass", "FailureMode", "FailureResult", "Severity", "Frequency", "Detec", "RPN", "RiskLevel" };
            var csv = new CsvSerializer<FaultSearchView> { UseLineNumbers = false };
            var sRet = csv.SerializeStream(list, headLine);
            string fileName = "FaultSearch_" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".csv";
            return File(sRet, "text/comma-separated-values", fileName);
        }
    }
}