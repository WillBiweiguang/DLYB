﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;


namespace Innocellence.FaultSearch.Controllers
{
    public class BFunctionSelectController : AdminBaseController<GasInputEntity, GasInputView>
    {
        private IGasInputService _gasService = new GasInputService();

        public BFunctionSelectController(IGasInputService objService)
            : base(objService)
        {
            _gasService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BBottleBasic/index";
            return View();
          
        }
        //public ActionResult Previous()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BBottleBasic/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}
    
        public ActionResult FaultSearch()
        {
            var id = Request["pid"];
            var isopen = Request["isopen"];
            var isnew = Request["isnew"];
            return Redirect("~/faultsearch/BSearchSelect/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        }
        public ActionResult FaultEval()
        {
            var id = Request["pid"];
            var isopen = Request["isopen"];
            var isnew = Request["isnew"];
            return Redirect("~/faultsearch/BEvalSelect/index?pid=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        }

       
       
    }
}