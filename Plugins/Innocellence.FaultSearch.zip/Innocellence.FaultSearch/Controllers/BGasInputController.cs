﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using EntityFramework.Extensions;

namespace Innocellence.FaultSearch.Controllers
{
    public class BGasInputController : AdminBaseController<GasInputEntity, GasInputView>
    {
        private IGasInputService _gasService = new GasInputService();

        public BGasInputController(IGasInputService objService)
            : base(objService)
        {
            _gasService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            var id = Request["Pid"];
            //ViewBag.preurl = "~/faultsearch/BFaultSearch/index";
            ViewBag.preurl = "~/faultsearch/BBottleBasic/index";
            ViewBag.nexturl = "~/faultsearch/BDetectInput/index";
            var obj = _gasService.GetInfo(int.Parse(id));

            return View(obj);

        }
        public ActionResult ReadIndex()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            var id = Request["pid"];
            ViewBag.preurl = "~/faultsearch/BBasicOpen/ReadIndex";
            ViewBag.nexturl = "~/faultsearch/BDetectInput/ReadIndex";
            var obj = _gasService.GetInfo(int.Parse(id));

            return View(obj);

        }


        public JsonResult Save(GasInputView objModal)
        {

            string Id = Request["pid"];
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }
            var id = int.Parse(Id);
            var num = _objService.Repository.Entities.Where(x => x.Id == id).ToList().Select(x => x.Id).FirstOrDefault();

            InsertOrUpdate(objModal, num == 0 ? "0" : num.ToString());
            return Json(new { Status = 200 }, JsonRequestBehavior.AllowGet);

        }

        protected void InsertOrUpdate(GasInputView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _objService.InsertView(objModal);
            }
            else
            {
                var id = int.Parse(Id);
                var num = _objService.Repository.Entities.Where(x => x.Id == id).Update(x => new GasInputEntity { UseCompany = objModal.UseCompany, MadeTime = objModal.MadeTime });

            }
        }

    }
}