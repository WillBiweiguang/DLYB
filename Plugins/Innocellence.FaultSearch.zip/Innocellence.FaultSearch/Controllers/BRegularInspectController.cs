﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using MSWord = Microsoft.Office.Interop.Word;
using System.IO;
using System.Reflection;
using Microsoft.Office.Interop.Word;
using EntityFramework.Extensions;
using Infrastructure.Core.Logging;
using System.Web.Hosting;
using Innocellence.CA.Contracts.CommonEntity;

namespace Innocellence.FaultSearch.Controllers
{
    //定期检验数据录入
    public class BRegularInspectController : AdminBaseController<RegularInspectEntity, RegularInspectView>
    {
        private IRegularInspectService _regService = new RegularInspectService();
        private IGasInputService _gasService = new GasInputService();
        private static ILogger logger = LogManager.GetLogger("respect");
        const string templatewordFilename = "/plugins/Innocellence.FaultSearch/content/Regular.doc";
        public BRegularInspectController(IRegularInspectService objService)
            : base(objService)
        {
            _regService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "/faultsearch/BDetectInput/index";
            ViewBag.nexturl = "~/faultsearch/BPostponeInput/index";
           
            ViewBag.list = _regService.GetRegularList(Request["pid"]);
            if (ViewBag.list.Count == 1)
            {
                GasInputView regular;

                regular = _gasService.GetRegularDetail(Request["pid"]);
                return View(regular.RI);
            }
            return View(new RegularInspectView());
        }
        public override ActionResult CheckIndex()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"];
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "/faultsearch/BDetectInput/index";
            //ViewBag.nexturl = "~/faultsearch/BUpload/index";
            GasInputView regular;

            regular = _gasService.GetRegularDetail(Request["pid"]);
            return View(regular);
        }
        public ActionResult ReadIndex()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "/faultsearch/BDetectInput/ReadIndex";
            ViewBag.nexturl = "~/faultsearch/BPostponeInput/ReadIndex";
            GasInputView regular;

            regular = _gasService.GetRegularDetail(Request["pid"]);

            return View(regular);
        }
        //public ActionResult Previous()
        //{

        //    return Redirect("~/faultsearch/BDetectInput/index");
        //}
        ////生成常规检查文档
        //public ActionResult Next()
        //{

        //    return Redirect("~/faultsearch/BPostponeInput/index");
        //}
        //Post方法
        public JsonResult GetRegularInfo(string pid, string name)
        {
            var regular = _regService.GetRegularInspectSingle(pid, name);
            return Json(new Result<RegularInspectView> { Status = 200, Data = regular }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Save(RegularInspectView objModal)
        {
            
            var pid = Request["pid"];
            //var num = _objService.Repository.Entities.Where(x => x.ProjectName == Id).ToList().Select(x => x.ProjectName).FirstOrDefault();
            var Id = _objService.Repository.Entities.Where(x => x.InspectNum == objModal.InspectNum && x.ProjectName== pid).ToList().Select(x => x.Id).FirstOrDefault();
            InsertOrUpdate(objModal, Id == null ? "" : Id.ToString());

            return Json(new { Status = 200 }, JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(RegularInspectView entity, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                entity.ProjectName = Request["pid"];
                _objService.InsertView(entity);
            }
            else
            {
                var pid = Request["pid"];
                var id = int.Parse(Id);
                var num = _objService.Repository.Entities.Where(x => x.Id == id).
                    Update(x => new RegularInspectEntity
                    {
                        ProjectName = pid,
                        InspectNum = entity.InspectNum,
                        InspectDes = entity.InspectDes,
                        TopOne = entity.TopOne,
                        TopTwo = entity.TopTwo,

                        BarrelOne = entity.BarrelOne,
                        BarrelTwo = entity.BarrelTwo,
                        BarrelThree = entity.BarrelThree,

                        BottomOne = entity.BottomOne,
                        BottomTwo = entity.BottomTwo,
                        BottomThree = entity.BottomThree,

                        VolumnTest = entity.VolumnTest,
                        WaterTest = entity.WaterTest,
                        BottleTest = entity.BottleTest,
                        GasTest = entity.GasTest,
                        VacuumTest = entity.VacuumTest,
                        SyncTest = entity.SyncTest,
                        EvalDate = entity.EvalDate,
                    });
                // _objService.UpdateView(objModal);
            }
        }
        [HttpPost]
        public ActionResult Export(RegularInspectView objModal, string[] nameList)
        {
            logger.Debug("进入应用");
            Application app = new Application();
            Document doc;

            string strFile = "regular" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".docx"; ;
            string strFileName1 = "/plugins/Innocellence.FaultSearch/content/regular.docx";
            string strFileName = Server.MapPath(strFileName1);
            string strFileName2 = "/plugins/Innocellence.FaultSearch/content/" + strFile;
            string strFileName3 = Server.MapPath(strFileName2);
            if (!System.IO.File.Exists((string)strFileName))
            {
                System.IO.File.Create(strFileName);
            }

            Object oMissing = System.Reflection.Missing.Value;

            doc = app.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);

            try
            {

                outPutWord(oMissing, app, doc, nameList);
                app.NormalTemplate.Saved = true;
                doc.SaveAs(strFileName3, oMissing);

            }
            catch (Exception ex)
            {
            }
            finally
            {
                if (doc != null)
                {
                    doc.Close();//关闭文档
                }
                if (app != null)
                {
                    app.Quit();//退出应用程序
                }
            }

            System.IO.FileStream fs = System.IO.File.OpenRead(strFileName3);
            byte[] fileB = new byte[fs.Length];
            fs.Read(fileB, 0, fileB.Length);
            return File(fileB, "application/ms-word", strFile);

        }
        //WORD输出
        public void outPutWord(Object oMissing, Application app, Document doc, string[] nameList)
        {
            logger.Debug("生成word");
            int rows = 10;//表格行数加1是为了标题栏
            int cols = 23;//表格列数

            //输出大标题加粗加大字号水平居中
            app.Selection.Font.Bold = 700;
            app.Selection.Font.Size = 16;
            app.Selection.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
            app.Selection.Text = "液 化 石 油 气 钢 瓶 延 期 使 用 安 全 评 估 报 告";

            //换行添加表格
            object line = Microsoft.Office.Interop.Word.WdUnits.wdLine;
            app.Selection.MoveDown(ref line, oMissing, oMissing);
            app.Selection.TypeParagraph();//换行
            Microsoft.Office.Interop.Word.Range range = app.Selection.Range;
            Microsoft.Office.Interop.Word.Table table = app.Selection.Tables.Add(range, rows, cols, ref oMissing, ref oMissing);

            //设置表格的字体大小粗细
            table.Range.Font.Size = 10;
            table.Range.Font.Bold = 0;
            //设置表格样式  
            table.Borders.OutsideLineStyle = WdLineStyle.wdLineStyleSingle;
            table.Borders.InsideLineStyle = WdLineStyle.wdLineStyleSingle;
            doc.PageSetup.LineNumbering.Active = 0;
            doc.PageSetup.Orientation = WdOrientation.wdOrientLandscape;
            doc.PageSetup.TopMargin = app.CentimetersToPoints(float.Parse("3.17"));
            doc.PageSetup.BottomMargin = app.CentimetersToPoints(float.Parse("3.17"));
            doc.PageSetup.LeftMargin = app.CentimetersToPoints(float.Parse("2.54"));
            doc.PageSetup.RightMargin = app.CentimetersToPoints(float.Parse("2.54"));
            doc.PageSetup.Gutter = app.CentimetersToPoints(float.Parse("0"));
            doc.PageSetup.HeaderDistance = app.CentimetersToPoints(float.Parse("1.5"));
            doc.PageSetup.FooterDistance = app.CentimetersToPoints(float.Parse("1.75"));
            doc.PageSetup.PageWidth = app.CentimetersToPoints(float.Parse("41.99"));
            doc.PageSetup.PageHeight = app.CentimetersToPoints(float.Parse("29.7"));
            doc.PageSetup.FirstPageTray = WdPaperTray.wdPrinterDefaultBin;
            doc.PageSetup.OtherPagesTray = WdPaperTray.wdPrinterDefaultBin;
            doc.PageSetup.SectionStart = WdSectionStart.wdSectionNewPage;
            doc.PageSetup.OddAndEvenPagesHeaderFooter = 0;
            doc.PageSetup.DifferentFirstPageHeaderFooter = 0;
            doc.PageSetup.VerticalAlignment = WdVerticalAlignment.wdAlignVerticalTop;
            doc.PageSetup.SuppressEndnotes = 0;
            doc.PageSetup.MirrorMargins = 0;
            doc.PageSetup.TwoPagesOnOne = false;
            doc.PageSetup.BookFoldPrinting = false;
            doc.PageSetup.BookFoldRevPrinting = false;
            doc.PageSetup.BookFoldPrintingSheets = 1;
            doc.PageSetup.GutterPos = WdGutterStyle.wdGutterPosLeft;
            //doc.PageSetup.LinesPage = 26;
            doc.PageSetup.LayoutMode = WdLayoutMode.wdLayoutModeLineGrid;
            //设置表格标题
            int rowIndex = 1;
            table.Cell(rowIndex, 1).Range.Text = "检验日期：20__年_月_日";//1行22列

            rowIndex++;
            table.Cell(rowIndex, 1).Range.Text = "检验编号";//4行1列
            table.Cell(rowIndex, 2).Range.Text = "使用单位";//4行1列
            table.Cell(rowIndex, 3).Range.Text = "原始标志";//1行6列

            table.Cell(rowIndex, 8).Range.Text = "技术检验";//1行12列

            table.Cell(rowIndex, 22).Range.Text = "综合评定";//4行1列
            table.Cell(rowIndex, 23).Range.Text = "评定有效日期";//4行1列

            rowIndex++;
            table.Cell(rowIndex, 3).Range.Text = "制造单位（代码）";//3行1列
            table.Cell(rowIndex, 4).Range.Text = "钢瓶编号";//3行1列
            table.Cell(rowIndex, 5).Range.Text = "公称容积（L）";//3行1列
            table.Cell(rowIndex, 6).Range.Text = "制造年月";//3行1列
            table.Cell(rowIndex, 7).Range.Text = "设计壁厚（mm）";//3行1列
            table.Cell(rowIndex, 8).Range.Text = "外观检查（包括焊接接头和底座）";//3行1列

            table.Cell(rowIndex, 9).Range.Text = "壁厚测定";//1行8列

            table.Cell(rowIndex, 17).Range.Text = "容积测定";//3行1列
            table.Cell(rowIndex, 18).Range.Text = "水压试验压力3.2MPa保压时间≥1min";//3行1列
            table.Cell(rowIndex, 19).Range.Text = "瓶阀检验";//3行1列
            table.Cell(rowIndex, 20).Range.Text = "气密性试验压力2.1MPa保压时间≥1min";//3行1列
            table.Cell(rowIndex, 21).Range.Text = "真空度MPa";//3行1列


            rowIndex++;
            table.Cell(rowIndex, 9).Range.Text = "顶部";//3行1列
            table.Cell(rowIndex, 11).Range.Text = "筒体";//3行1列
            table.Cell(rowIndex, 14).Range.Text = "底部";//3行1列



            rowIndex++;


            table.Cell(rowIndex, 9).Range.Text = "1";//3行1列
            table.Cell(rowIndex, 10).Range.Text = "2";//3行1列
            table.Cell(rowIndex, 11).Range.Text = "1";//3行1列
            table.Cell(rowIndex, 12).Range.Text = "2";//3行1列
            table.Cell(rowIndex, 13).Range.Text = "3";//3行1列
            table.Cell(rowIndex, 14).Range.Text = "1";//3行1列
            table.Cell(rowIndex, 15).Range.Text = "2";//3行1列
            table.Cell(rowIndex, 16).Range.Text = "3";//3行1列

            logger.Debug("Enter pid!" + Request["pid"]);

            rowIndex++;
            GasInputView regular = _gasService.GetRegularFromGas(Request["pid"],Request["InspectNum"]);
            if (!string.IsNullOrEmpty(regular.RI.InspectNum))
            {
                table.Cell(rowIndex, 1).Range.Text = regular.RI.InspectNum;
            }
            if (!string.IsNullOrEmpty(regular.UseCompany))
            {
                table.Cell(rowIndex, 2).Range.Text = regular.UseCompany;
            }
            if (!string.IsNullOrEmpty(regular.MadeCompany))
            {
                table.Cell(rowIndex, 3).Range.Text = regular.MadeCompany;//3行1列
            }
            if (!string.IsNullOrEmpty(regular.BottleNum))
            {
                table.Cell(rowIndex, 4).Range.Text = regular.BottleNum;
            }
            if (!string.IsNullOrEmpty(regular.Volume))
            {
                table.Cell(rowIndex, 5).Range.Text = regular.Volume;
            }
            if (!string.IsNullOrEmpty(regular.MadeTime.ToString()))
            {
                table.Cell(rowIndex, 6).Range.Text = regular.MadeTime.ToString();
            }
            if (!string.IsNullOrEmpty(regular.DesignWall))
            {
                table.Cell(rowIndex, 7).Range.Text = regular.DesignWall;
            }
            if (!string.IsNullOrEmpty(regular.RI.InspectDes))
            {
                table.Cell(rowIndex, 8).Range.Text = regular.RI.InspectDes;
            }
            if (!string.IsNullOrEmpty(regular.RI.TopOne))
            {
                table.Cell(rowIndex, 9).Range.Text = regular.RI.TopOne;//3行1列
            }
            if (!string.IsNullOrEmpty(regular.RI.TopTwo))
            {
                table.Cell(rowIndex, 10).Range.Text = regular.RI.TopTwo;//3行1列
            }
            if (!string.IsNullOrEmpty(regular.RI.BarrelOne))
            {
                table.Cell(rowIndex, 11).Range.Text = regular.RI.BarrelOne;//3行1列
            }
            if (!string.IsNullOrEmpty(regular.RI.BarrelTwo))
            {
                table.Cell(rowIndex, 12).Range.Text = regular.RI.BarrelTwo;//3行1列
            }
            if (!string.IsNullOrEmpty(regular.RI.BarrelThree))
            {
                table.Cell(rowIndex, 13).Range.Text = regular.RI.BarrelThree;//1行8列
            }
            if (!string.IsNullOrEmpty(regular.RI.BottomOne))
            {
                table.Cell(rowIndex, 14).Range.Text = regular.RI.BottomOne;//3行1列
            }
            if (!string.IsNullOrEmpty(regular.RI.BottomTwo))
            {
                table.Cell(rowIndex, 15).Range.Text = regular.RI.BottomTwo;//3行1列
            }
            if (!string.IsNullOrEmpty(regular.RI.BottomThree))
            {
                table.Cell(rowIndex, 16).Range.Text = regular.RI.BottomThree;//1行8列
            }
            if (!string.IsNullOrEmpty(regular.RI.VolumnTest))
            {
                table.Cell(rowIndex, 17).Range.Text = regular.RI.VolumnTest;
            }
            if (!string.IsNullOrEmpty(regular.RI.WaterTest))
            {
                table.Cell(rowIndex, 18).Range.Text = regular.RI.WaterTest;
            }
            if (!string.IsNullOrEmpty(regular.RI.BottleTest))
            {
                table.Cell(rowIndex, 19).Range.Text = regular.RI.BottleTest;
            }
            if (!string.IsNullOrEmpty(regular.RI.GasTest))
            {
                table.Cell(rowIndex, 20).Range.Text = regular.RI.GasTest;
            }
            if (!string.IsNullOrEmpty(regular.RI.VacuumTest))
            {
                table.Cell(rowIndex, 21).Range.Text = regular.RI.VacuumTest;
            }
            if (!string.IsNullOrEmpty(regular.RI.SyncTest))
            {
                table.Cell(rowIndex, 22).Range.Text = regular.RI.SyncTest;
            }
            if (regular.RI.EvalDate != null)
            {
                table.Cell(rowIndex, 23).Range.Text = regular.RI.EvalDate.ToString();
            }
            //合并单元格  
            table.Cell(1, 1).Merge(table.Cell(1, 23));
            //合并单元格  
            table.Cell(2, 1).Merge(table.Cell(5, 1));
            table.Cell(2, 2).Merge(table.Cell(5, 2));
            table.Cell(2, 3).Merge(table.Cell(2, 7));
            table.Cell(2, 4).Merge(table.Cell(2, 17));
            table.Cell(2, 5).Merge(table.Cell(5, 22));
            table.Cell(2, 6).Merge(table.Cell(5, 23));

            table.Cell(3, 3).Merge(table.Cell(5, 3));
            table.Cell(3, 4).Merge(table.Cell(5, 4));
            table.Cell(3, 5).Merge(table.Cell(5, 5));
            table.Cell(3, 6).Merge(table.Cell(5, 6));
            table.Cell(3, 7).Merge(table.Cell(5, 7));
            table.Cell(3, 8).Merge(table.Cell(5, 8));

            table.Cell(3, 9).Merge(table.Cell(3, 16));
            table.Cell(3, 10).Merge(table.Cell(5, 17));
            table.Cell(3, 11).Merge(table.Cell(5, 18));
            table.Cell(3, 12).Merge(table.Cell(5, 19));
            table.Cell(3, 13).Merge(table.Cell(5, 20));
            table.Cell(3, 14).Merge(table.Cell(5, 21));

            table.Cell(4, 9).Merge(table.Cell(4, 10));
            table.Cell(4, 10).Merge(table.Cell(4, 12));
            table.Cell(4, 11).Merge(table.Cell(4, 13));
            table.AutoFitBehavior(WdAutoFitBehavior.wdAutoFitWindow);


            //for (int i = 1; i < 24; i++)
            //{
            //    table.Cell(2, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
            //    table.Cell(3, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
            //    table.Cell(4, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
            //    table.Cell(5, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

            //}

            app.Selection.Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
        }
    }
}