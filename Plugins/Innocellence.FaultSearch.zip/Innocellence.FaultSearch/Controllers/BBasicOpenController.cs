﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using Innocellence.CA.Contracts.CommonEntity;
using EntityFramework.Extensions;

namespace Innocellence.FaultSearch.Controllers
{
    public class BBasicOpenController : AdminBaseController<GasInputEntity, GasInputView>
    {
        private IGasInputService _gasService = new GasInputService();
        private readonly IPostponeInspectService _objPostponeService = new PostponeInspectService();
        private readonly IRegularInspectService _objRegularService = new RegularInspectService();
        public BBasicOpenController(IGasInputService gasService)
            : base(gasService)
        {
            _gasService = gasService;
        }

        public override ActionResult Index()
        {

            ViewBag.list = _gasService.GetBasicQuerys();

            ViewBag.nexturl = "~/faultsearch/BDetectInput/index";
            return View();
          
        }
        public  ActionResult ReadIndex()
        {

            ViewBag.list = _gasService.GetBasicQuerys();

            ViewBag.nexturl = "~/faultsearch/BDetectInput/index";
            return View();

        }
        public ActionResult GetBasicQuerys()
        {
            var list = _gasService.GetBasicQuerys();

            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetPostponeQuerys()
        {
            var list = _objPostponeService.GetPostponeQuerys();

            return Json(list, JsonRequestBehavior.AllowGet);
        }
        //public ActionResult Next()
        //{

        //    return Redirect("~/faultsearch/BFunctionSelect/index");
        //}
        public JsonResult GetGasInfo(string name)
        {
            var gas = _gasService.GetInfoViaName(name);
            return Json(new Result<GasInputView> { Status = 200, Data = gas }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPostponeInfo(string name, string projectName)
        {
            var postpone= _objPostponeService.GetPostponeSingle(name, projectName);
            return Json(new Result<PostponeInspectView> { Status = 200, Data = postpone }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetRegularInfo(string name, string projectName)
        {
            var regular = _objRegularService.GetRegularInspectSingle(name, projectName);
            return Json(new Result<RegularInspectView> { Status = 200, Data = regular }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetGasInfoviaProject(string name,string projectName)
        {
            var gas = _gasService.GetInfoviaProject(name, projectName);
            return Json(new Result<GasInputView> { Status = 200, Data = gas }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetAllGasInfo(string id,string projectName)
        {
            var gas = _gasService.GetAllReadInfo(id, projectName);
            return Json(new Result<GasInputView> { Status = 200, Data = gas }, JsonRequestBehavior.AllowGet);
        }
        //Post方法

        public JsonResult Save(GasInputView objModal,string Id)
        {
            var name = Request["name"];
            var projectName = Request["projectName"];
            var gas = _gasService.GetInfoviaProject(name, projectName);
            if (gas != null)
            {
                var id = gas.Id;
                _gasService.Repository.Entities.Where(x => x.Id == id).
                    Update(x => new GasInputEntity { UseCompany = objModal.UseCompany,MadeTime = objModal.MadeTime });
            }
            return Json(new Result<int> { Status = 200,  Message = "保存成功。" }, JsonRequestBehavior.AllowGet);

        }

        
       
    }
}