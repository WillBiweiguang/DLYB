﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using Innocellence.CA.Contracts.CommonEntity;
using EntityFramework.Extensions;

namespace Innocellence.FaultSearch.Controllers
{
    //探测度(D)评价准则
    public class BUploadController : AdminBaseController<AnsysTypeEntity, AnsysTypeView>
    {
        private IAnsysTypeService _anyService = new AnsysTypeService();
        private IGasInputService _gasService = new GasInputService();
        public BUploadController(IAnsysTypeService objService)
            : base(objService)
        {
            _anyService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"];
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BDetectInput/index";
            ViewBag.list = _gasService.GetBasicQuerys();
            var gas = _gasService.GetAnsysDetail(Request["pid"]);
            return View(gas);
        }
        public ActionResult Readindex()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"];
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BDetectInput/Readindex";
            ViewBag.list = _gasService.GetBasicQuerys();
            //var gas = _gasService.GetAnsysDetail(Request["pid"]);
            return View();
        }
        public override ActionResult CheckIndex()
        {
            ViewBag.list = _gasService.GetBasicQuerys();
            return View();
        }
        public JsonResult GetGasInfo(string name)
        {
            var gas = _gasService.GetInfoViaName(name);
            return Json(new Result<GasInputView> { Status = 200, Data = gas }, JsonRequestBehavior.AllowGet);
        }
        //Post方法
        [HttpPost]
        public ActionResult Save(AnsysTypeView objModal, string id)
        {
            objModal.ProjectName = Request["pid"];
            objModal.Category = objModal.Category;

            var num = _anyService.Repository.Entities.Where(x => x.ProjectName == objModal.ProjectName && x.Category == objModal.Category)
                .ToList().Select(x => x.Id).FirstOrDefault();

            //if (num == 0)
            //{
            //    _anyService.InsertView(objModal);
            //}
            //else
            //{
            //    var num1 = num;
            //    _anyService.Repository.Entities.Where(x => x.Id == num1)
            //        .Update(x => new AnsysTypeEntity { ProjectName = objModal.ProjectName, Category = objModal.Category }); 
            //}
            id = num.ToString();
            //return Json(new { rtnId = objModal.Id, str = "Insert Success." });
          
            InsertOrUpdate(objModal, id);

            return Json(new { rtnId = objModal.Id, str = "Insert Success." }, JsonRequestBehavior.AllowGet);

        }

        protected void InsertOrUpdate(AnsysTypeView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                objModal.ProjectName = Request["pid"];
                _objService.InsertView(objModal);
            }
            else
            {
                objModal.ProjectName = Request["pid"];
                objModal.Id = int.Parse(Id);
                _objService.UpdateView(objModal);
            }
        }
        [HttpPost]
        public ActionResult EditImage(string pid, string category)
        {
            if (!string.IsNullOrEmpty(pid) && pid != "0")
            {
                var questionView = _anyService.GetImagesDetail(pid, category);
                return Json(new Result<AnsysTypeView> { Status = 200, Data = questionView }, JsonRequestBehavior.AllowGet);
            }

            return Json(null, JsonRequestBehavior.AllowGet);
        }

    }
}