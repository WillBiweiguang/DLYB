﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using Innocellence.CA.Contracts.CommonEntity;
using EntityFramework.Extensions;
using Infrastructure.Utility.Extensions;

namespace Innocellence.FaultSearch.Controllers
{
    public class BBottleSearchController : AdminBaseController<GasInputEntity, GasInputView>
    {
        private IGasInputService _fautService = new GasInputService();

        public BBottleSearchController(IGasInputService objService)
            : base(objService)
        {
            _fautService = objService;
        }

        public override ActionResult Index()
        {
            
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; 
            ViewBag.isnew = Request["isnew"];
            return View();
        }
        public ActionResult ReadIndex()
        {
          
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"]; ;
            ViewBag.isnew = Request["isnew"];
         
            return View();
        }
       


        public override List<GasInputView> GetListEx(Expression<Func<GasInputEntity, bool>> predicate, PageCondition ConPage)
        {
            predicate = predicate.AndAlso(a => a.IsDeleted != true);

            var q = _BaseService.GetList<GasInputView>(predicate, ConPage).DistinctBy(p => new { p.BottleNum }).ToList();

            return q;
        }
        public override ActionResult Edit(string id)
        {
           
            var obj = GetObject(id);

            return View(obj);
        }

        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(GasInputView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            int id = _fautService.GetId(objModal.BottleNum);
            if (id > 0)
            {

                //var lst = new List<string>() { "MadeCompany", "Volume", "DesignWall" };
                //_objService.UpdateView(objModal, lst);
                var num = _objService.Repository.Entities.Where(x => x.Id == id).Update(x => new GasInputEntity { DesignWall = objModal.DesignWall, MadeCompany = objModal.MadeCompany, Volume = objModal.Volume });
                return Json(doJson(null), JsonRequestBehavior.AllowGet);
            }
            InsertOrUpdate(objModal, Id);
            return Json(doJson(null), JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(GasInputView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _BaseService.InsertView(objModal);
            }
            else
            {
                _BaseService.UpdateView(objModal);
            }
        }

        public override ActionResult Export()
        {

            Expression<Func<GasInputEntity, bool>> predicate = x => x.Id > 0;
          
            predicate = predicate.AndAlso(a => a.IsDeleted != true);
            var reportList = _fautService.GetList<GasInputView>(predicate).DistinctBy(p => new { p.BottleNum }).OrderByDescending(x => x.Id).ToList();

            return ExportToCsv(reportList);
        }

        private ActionResult ExportToCsv(List<GasInputView> list)
        {
            string[] headLine = { "Id","BottleNum", "Volume", "DesignWall" , "MadeCompany" };
            var csv = new CsvSerializer<GasInputView> { UseLineNumbers = false };
            var sRet = csv.SerializeStream(list, headLine);
            string fileName = "GasInput_" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".csv";
            return File(sRet, "text/comma-separated-values", fileName);
        }
    }
}