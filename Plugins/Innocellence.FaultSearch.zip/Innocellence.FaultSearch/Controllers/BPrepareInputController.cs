﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using MSWord = Microsoft.Office.Interop.Word;
using System.IO;
using System.Reflection;
using Microsoft.Office.Interop.Word;
namespace Innocellence.FaultSearch.Controllers
{
    public class BPrepareInputController : AdminBaseController<FaultSearchEntity, FaultSearchView>
    {
        private IFaultSearchService _fautService = new FaultSearchService();

        public BPrepareInputController(IFaultSearchService objService)
            : base(objService)
        {
            _fautService = objService;
        }

        public override ActionResult Index()
        {

            return View();
        }
        public ActionResult Previous()
        {

            return Redirect("~/faultsearch/BDetectInput/index");
        }
        public ActionResult Next()
        {

            return Redirect("~/faultsearch/BOutInspect/index");
        }
        [HttpPost]
        public ActionResult Create(FaultSearchView objModal, string Id)
        {
            Application app = new Application();
            Document doc;
            string strContent = "";

            object strFileName = Server.MapPath("~/temp/test.doc");
            if (System.IO.File.Exists((string)strFileName))
                System.IO.File.Delete((string)strFileName);
            Object oMissing = System.Reflection.Missing.Value;
            doc = app.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            try
            {
                int type = 2;
                if (type == 1)
                {
                    outPutWord(oMissing, app, doc);

                }
                else
                {
                    outPutPostponeWord(oMissing, app, doc);
                }
                //导出到文件
                //string newFile = DateTime.Now.ToString("yyyyMMddHHmmssss") + ".doc";
                //string physicNewFile = Server.MapPath(newFile);
                doc.SaveAs(strFileName,
                oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing, oMissing,
                oMissing, oMissing, oMissing, oMissing, oMissing, oMissing);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                if (doc != null)
                {
                    doc.Close();//关闭文档
                }
                if (app != null)
                {
                    app.Quit();//退出应用程序
                }
            }

            return null;

        }
        //WORD输出
        public void outPutWord(Object oMissing, Application app, Document doc)
        {
            int rows = 10;//表格行数加1是为了标题栏
            int cols = 23;//表格列数

            //输出大标题加粗加大字号水平居中
            app.Selection.Font.Bold = 700;
            app.Selection.Font.Size = 16;
            app.Selection.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
            app.Selection.Text = "液 化 石 油 气 钢 瓶 延 期 使 用 安 全 评 估 报 告";

            //换行添加表格
            object line = Microsoft.Office.Interop.Word.WdUnits.wdLine;
            app.Selection.MoveDown(ref line, oMissing, oMissing);
            app.Selection.TypeParagraph();//换行
            Microsoft.Office.Interop.Word.Range range = app.Selection.Range;
            Microsoft.Office.Interop.Word.Table table = app.Selection.Tables.Add(range, rows, cols, ref oMissing, ref oMissing);

            //设置表格的字体大小粗细
            table.Range.Font.Size = 10;
            table.Range.Font.Bold = 0;
            //设置表格样式  
            table.Borders.OutsideLineStyle = WdLineStyle.wdLineStyleSingle;
            table.Borders.InsideLineStyle = WdLineStyle.wdLineStyleSingle;
            //设置表格标题
            int rowIndex = 1;
            table.Cell(rowIndex, 1).Range.Text = "检验日期：20__年_月_日";//1行22列

            rowIndex++;
            table.Cell(rowIndex, 1).Range.Text = "检验编号";//4行1列
            table.Cell(rowIndex, 2).Range.Text = "使用单位";//4行1列
            table.Cell(rowIndex, 3).Range.Text = "原始标志";//1行6列

            table.Cell(rowIndex, 8).Range.Text = "技术检验";//1行12列

            table.Cell(rowIndex, 22).Range.Text = "综合评定";//4行1列
            table.Cell(rowIndex, 23).Range.Text = "评定有效日期";//4行1列

            rowIndex++;
            table.Cell(rowIndex, 3).Range.Text = "制造单位（代码）";//3行1列
            table.Cell(rowIndex, 4).Range.Text = "钢瓶编号";//3行1列
            table.Cell(rowIndex, 5).Range.Text = "公称容积（L）";//3行1列
            table.Cell(rowIndex, 6).Range.Text = "制造年月";//3行1列
            table.Cell(rowIndex, 7).Range.Text = "设计壁厚（mm）";//3行1列
            table.Cell(rowIndex, 8).Range.Text = "外观检查（包括焊接接头和底座）";//3行1列

            table.Cell(rowIndex, 9).Range.Text = "壁厚测定";//1行8列

            table.Cell(rowIndex, 17).Range.Text = "容积测定";//3行1列
            table.Cell(rowIndex, 18).Range.Text = "水压试验压力3.2MPa保压时间≥1min";//3行1列
            table.Cell(rowIndex, 19).Range.Text = "瓶阀检验";//3行1列
            table.Cell(rowIndex, 20).Range.Text = "气密性试验压力2.1MPa保压时间≥1min";//3行1列
            table.Cell(rowIndex, 21).Range.Text = "真空度MPa";//3行1列


            rowIndex++;
            table.Cell(rowIndex, 9).Range.Text = "顶部";//3行1列
            table.Cell(rowIndex, 11).Range.Text = "筒体";//3行1列
            table.Cell(rowIndex, 14).Range.Text = "底部";//3行1列



            rowIndex++;


            table.Cell(rowIndex, 9).Range.Text = "1";//3行1列
            table.Cell(rowIndex, 10).Range.Text = "2";//3行1列
            table.Cell(rowIndex, 11).Range.Text = "1";//3行1列
            table.Cell(rowIndex, 12).Range.Text = "2";//3行1列
            table.Cell(rowIndex, 13).Range.Text = "3";//3行1列
            table.Cell(rowIndex, 14).Range.Text = "1";//3行1列
            table.Cell(rowIndex, 15).Range.Text = "2";//3行1列
            table.Cell(rowIndex, 16).Range.Text = "3";//3行1列

            //合并单元格  
            table.Cell(1, 1).Merge(table.Cell(1, 23));
            //合并单元格  
            table.Cell(2, 1).Merge(table.Cell(5, 1));
            table.Cell(2, 2).Merge(table.Cell(5, 2));
            table.Cell(2, 3).Merge(table.Cell(2, 7));
            table.Cell(2, 4).Merge(table.Cell(2, 17));
            table.Cell(2, 5).Merge(table.Cell(5, 22));
            table.Cell(2, 6).Merge(table.Cell(5, 23));

            table.Cell(3, 3).Merge(table.Cell(5, 3));
            table.Cell(3, 4).Merge(table.Cell(5, 4));
            table.Cell(3, 5).Merge(table.Cell(5, 5));
            table.Cell(3, 6).Merge(table.Cell(5, 6));
            table.Cell(3, 7).Merge(table.Cell(5, 7));
            table.Cell(3, 8).Merge(table.Cell(5, 8));

            table.Cell(3, 9).Merge(table.Cell(3, 16));
            table.Cell(3, 10).Merge(table.Cell(5, 17));
            table.Cell(3, 11).Merge(table.Cell(5, 18));
            table.Cell(3, 12).Merge(table.Cell(5, 19));
            table.Cell(3, 13).Merge(table.Cell(5, 20));
            table.Cell(3, 14).Merge(table.Cell(5, 21));

            table.Cell(4, 9).Merge(table.Cell(4, 10));
            table.Cell(4, 10).Merge(table.Cell(4, 12));
            table.Cell(4, 11).Merge(table.Cell(4, 13));

            for (int i = 1; i < 24; i++)
            {
                table.Cell(2, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                table.Cell(3, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                table.Cell(4, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                table.Cell(5, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

            }

            app.Selection.Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
        }
        //word延期检验输出
        public void outPutPostponeWord(Object oMissing, Application app, Document doc)
        {
            int rows = 10;//表格行数加1是为了标题栏
            int cols = 22;//表格列数

            //输出大标题加粗加大字号水平居中
            app.Selection.Font.Bold = 700;
            app.Selection.Font.Size = 16;
            app.Selection.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
            app.Selection.Text = "液 化 石 油 气 钢 瓶 延 期 使 用 安 全 评 估 报 告";

            //换行添加表格
            object line = Microsoft.Office.Interop.Word.WdUnits.wdLine;
            app.Selection.MoveDown(ref line, oMissing, oMissing);
            app.Selection.TypeParagraph();//换行
            Microsoft.Office.Interop.Word.Range range = app.Selection.Range;
            Microsoft.Office.Interop.Word.Table table = app.Selection.Tables.Add(range, rows, cols, ref oMissing, ref oMissing);

            //设置表格的字体大小粗细
            table.Range.Font.Size = 10;
            table.Range.Font.Bold = 0;
            //设置表格样式  
            table.Borders.OutsideLineStyle = WdLineStyle.wdLineStyleSingle;
            table.Borders.InsideLineStyle = WdLineStyle.wdLineStyleSingle;
            //设置表格标题
            int rowIndex = 1;
            table.Cell(rowIndex, 1).Range.Text = "检验日期：20__年_月_日";//1行22列

            rowIndex++;
            table.Cell(rowIndex, 1).Range.Text = "检验编号";//4行1列
            table.Cell(rowIndex, 2).Range.Text = "使用单位";//4行1列
            table.Cell(rowIndex, 3).Range.Text = "原始标志";//1行6列

            table.Cell(rowIndex, 9).Range.Text = "技术检验";//1行12列

            table.Cell(rowIndex, 21).Range.Text = "综合评定";//4行1列
            table.Cell(rowIndex, 22).Range.Text = "评定有效日期";//4行1列

            rowIndex++;
            table.Cell(rowIndex, 3).Range.Text = "制造单位（代码）";//3行1列
            table.Cell(rowIndex, 4).Range.Text = "钢瓶编号";//3行1列
            table.Cell(rowIndex, 5).Range.Text = "公称容积（L）";//3行1列
            table.Cell(rowIndex, 6).Range.Text = "制造年月";//3行1列
            table.Cell(rowIndex, 7).Range.Text = "设计壁厚（mm）";//3行1列
            table.Cell(rowIndex, 8).Range.Text = "延期次数";//3行1列

            table.Cell(rowIndex, 9).Range.Text = "壁厚测定";//1行8列

            table.Cell(rowIndex, 17).Range.Text = "探伤测定";//3行1列



            rowIndex++;
            table.Cell(rowIndex, 9).Range.Text = "上封头圆弧过渡区";//3行1列
            table.Cell(rowIndex, 10).Range.Text = "下封头圆弧过渡区";//3行1列
            table.Cell(rowIndex, 11).Range.Text = "焊缝1";//3行1列
            table.Cell(rowIndex, 13).Range.Text = "(焊缝2)";//3行1列
            table.Cell(rowIndex, 15).Range.Text = "(筒体中部)";//3行1列
            table.Cell(rowIndex, 16).Range.Text = "上封头圆弧过渡区";//3行1列
            table.Cell(rowIndex, 17).Range.Text = "下封头圆弧过渡区";//3行1列
            table.Cell(rowIndex, 18).Range.Text = "焊缝1";//3行1列
            table.Cell(rowIndex, 19).Range.Text = "(焊缝2)";//3行1列
            table.Cell(rowIndex, 20).Range.Text = "(筒体中部)";//3行1列


            rowIndex++;


            table.Cell(rowIndex, 11).Range.Text = "上";//3行1列
            table.Cell(rowIndex, 12).Range.Text = "下";//3行1列
            table.Cell(rowIndex, 13).Range.Text = "上";//3行1列
            table.Cell(rowIndex, 14).Range.Text = "下";//3行1列


            //合并单元格  
            table.Cell(1, 1).Merge(table.Cell(1, 22));
            //合并单元格  
            table.Cell(2, 1).Merge(table.Cell(5, 1));
            table.Cell(2, 2).Merge(table.Cell(5, 2));
            table.Cell(2, 3).Merge(table.Cell(2, 8));
            table.Cell(2, 4).Merge(table.Cell(2, 15));
            table.Cell(2, 5).Merge(table.Cell(5, 21));
            table.Cell(2, 6).Merge(table.Cell(5, 22));

            table.Cell(3, 3).Merge(table.Cell(5, 3));
            table.Cell(3, 4).Merge(table.Cell(5, 4));
            table.Cell(3, 5).Merge(table.Cell(5, 5));
            table.Cell(3, 6).Merge(table.Cell(5, 6));
            table.Cell(3, 7).Merge(table.Cell(5, 7));
            table.Cell(3, 8).Merge(table.Cell(5, 8));
            table.Cell(3, 9).Merge(table.Cell(3, 14));
            table.Cell(3, 10).Merge(table.Cell(3, 15));


            table.Cell(4, 9).Merge(table.Cell(5, 9));
            table.Cell(4, 10).Merge(table.Cell(5, 10));
            table.Cell(4, 11).Merge(table.Cell(4, 12));
            table.Cell(4, 12).Merge(table.Cell(4, 13));
            table.Cell(4, 13).Merge(table.Cell(5, 15));
            table.Cell(4, 14).Merge(table.Cell(5, 16));
            table.Cell(4, 15).Merge(table.Cell(5, 17));
            table.Cell(4, 16).Merge(table.Cell(5, 18));
            table.Cell(4, 17).Merge(table.Cell(5, 19));
            table.Cell(4, 18).Merge(table.Cell(5, 20));

            for (int i = 1; i < 23; i++)
            {
                table.Cell(2, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                table.Cell(3, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                table.Cell(4, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                table.Cell(5, i).VerticalAlignment = Microsoft.Office.Interop.Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

            }

            app.Selection.Cells.VerticalAlignment = WdCellVerticalAlignment.wdCellAlignVerticalCenter;
        }
        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(FaultSearchView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            InsertOrUpdate(objModal, Id);

            return Json(doJson(null), JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(FaultSearchView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _BaseService.InsertView(objModal);
            }
            else
            {
                _BaseService.UpdateView(objModal);
            }
        }

    }
}