﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;


namespace Innocellence.FaultSearch.Controllers
{
    //探测度(D)评价准则
    public class BDetecTestController : AdminBaseController<FaultSearchEntity, FaultSearchView>
    {
        private IFaultSearchService _detService = new FaultSearchService();

        public BDetecTestController(IFaultSearchService objService)
            : base(objService)
        {
            _detService = objService;
        }

        public override ActionResult Index()
        {
            ViewBag.id = Request["pid"];
            ViewBag.isopen = Request["isopen"];
            ViewBag.isnew = Request["isnew"];
            ViewBag.preurl = "~/faultsearch/BFrequencyTest/index";
            ViewBag.nexturl = "~/faultsearch/BRiskTest/index";
            return View();
        }
        //public ActionResult Previous()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BFrequencyTest/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}
        //public ActionResult Next()
        //{
        //    var id = Request["id"];
        //    var isopen = Request["isopen"];
        //    var isnew = Request["isnew"];
        //    return Redirect("~/faultsearch/BRiskTest/index?id=" + id + "&isopen=" + isopen + "&isnew=" + isnew);
        //}
        //Post方法
        [HttpPost]
        [ValidateInput(false)]
        public override JsonResult Post(FaultSearchView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }

            InsertOrUpdate(objModal, Id);

            return Json(doJson(null), JsonRequestBehavior.AllowGet);
        }

        protected void InsertOrUpdate(FaultSearchView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _BaseService.InsertView(objModal);
            }
            else
            {
                _BaseService.UpdateView(objModal);
            }
        }
       
    }
}