﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using Infrastructure.Utility.Data;
using Infrastructure.Utility.IO;
using Infrastructure.Web.UI;
using Innocellence.FaultSearch.Model;
using Innocellence.FaultSearch.Services;
using Innocellence.FaultSearch.ViewModel;
using Innocellence.FaultSearch.Service;
using Innocellence.CA.Contracts.CommonEntity;
using EntityFramework.Extensions;
namespace Innocellence.FaultSearch.Controllers
{
    public class BBottleBasicController : AdminBaseController<GasInputEntity, GasInputView>
    {
        private IGasInputService _botService = new GasInputService();

        public BBottleBasicController(IGasInputService objService)
            : base(objService)
        {
            _botService = objService;
        }

        public override ActionResult Index()
        {

            string id = "0";
            var obj = GetObject(id);

            ViewBag.list = _botService.GetBasicQuerys();
            ViewBag.nexturl = "~/faultsearch/BDetectInput/index";
            return View(obj);

        }
        public JsonResult GetGasInfo(string name)
        {
            var gas = _botService.GetInfoViaName(name);
            return Json(new Result<GasInputView> { Status = 200, Data = gas }, JsonRequestBehavior.AllowGet);
        }

        //Post方法

        public JsonResult Save(GasInputView objModal, string Id)
        {
            //验证错误
            if (!BeforeAddOrUpdate(objModal, Id) || !ModelState.IsValid)
            {
                return Json(GetErrorJson(), JsonRequestBehavior.AllowGet);
            }
            int id = _botService.GetProjectId(objModal.BottleNum,objModal.ProjectName);
            if (id > 0)
            {

                //var lst = new List<string>() { "MadeCompany", "Volume", "DesignWall" };
                //_objService.UpdateView(objModal, lst);
                var num = _objService.Repository.Entities.Where(x => x.Id == id).Update(x => new GasInputEntity { UseCompany = objModal.UseCompany, MadeTime = objModal.MadeTime });

                return Json(new Result<int> { Status = 200, Data = id, Message = "气瓶信息已存在,只能更新制造年月、使用单位信息。" }, JsonRequestBehavior.AllowGet);
            }
            InsertOrUpdate(objModal, Id);
            var id1 = _botService.GetProjectId(objModal.BottleNum, objModal.ProjectName);
            return Json(new Result<int> { Status = 200, Data = id1, Message = "保存成功。" }, JsonRequestBehavior.AllowGet);

        }

        protected void InsertOrUpdate(GasInputView objModal, string Id)
        {
            if (string.IsNullOrEmpty(Id) || Id == "0")
            {
                _objService.InsertView(objModal);

            }
            else
            {
                _objService.UpdateView(objModal);
            }
        }

    }
}